 const Discord = require("discord.js")
  const { PermissionsBitField } = require("discord.js")
  const { StringSelectMenuBuilder, StringSelectMenuOptionBuilder , EmbedBuilder , ButtonBuilder , ActionRowBuilder, MessageAttachment , Events , ButtonStyle , Client , GatewayIntentBits , TextInputBuilder, TextInputStyle, ModalBuilder, setPlaceholder, addOptions, setCustomId, addComponents, ChannelType, processTicksAndRejections, message, reading, guild, MessageEmbed,SelectMenuBuilder,SelectMenuOptionBuilder,voiceAdapterCreator, AttachmentBuilder, feedbackButtons,} = require("discord.js")
  const { joinVoiceChannel } = require('@discordjs/voice');
  const chalk = require('chalk');
  const config = require("./config.json")
  const Database = require("st.db")
  const db = new Database("database.json")
  const db2 = require("quick.db")
  // Discord Client Constructor
  const client = new Discord.Client({
    intents: [
      Discord.GatewayIntentBits.Guilds,
      Discord.GatewayIntentBits.GuildMembers,
      Discord.GatewayIntentBits.GuildMessages,
      Discord.GatewayIntentBits.MessageContent,
      Discord.GatewayIntentBits.DirectMessages,
      Discord.GatewayIntentBits.GuildVoiceStates, 
      Discord.GatewayIntentBits.GuildMessageReactions
    ]
  });

  const express = require("express")
  const app = express();

  app.listen(() => console.log("I'm Ready To Work..! 24H"));
  app.get('/', (req, res) => {
    res.send(`
    <body>
    <center><h1>Bot 24H ON!</h1></center
    </body>`)
  });


  //يسوي ريستارت للبوت اذا علق (kill bot / project)

  setInterval(() => {
if(!client.user || !client){
    console.log("client don't respond , kill it")

  process.kill(1)
} else {
  return
}
},10000)



// Anti Crash - ما يخلي البوت يطفي لايرور بالكود

process.on('unhandledRejection', (reason, p) => {
  console.log(chalk.bold.redBright('[antiCrash] :: Unhandled Rejection/Catch'));
  console.log(reason?.stack, p);
});

process.on("uncaughtException", (err, origin) => {
  console.log(chalk.bold.redBright('[antiCrash] :: ncaught Exception/Catch'));
  console.log(err?.stack, origin);
});

process.on('uncaughtExceptionMonitor', (err, origin) => {
  console.log(chalk.bold.redBright('[antiCrash] :: Uncaught Exception/Catch (MONITOR)'));
  console.log(err?.stack, origin);
});


client.on('ready', async () => {

  console.log(chalk.bold.greenBright(`${client.user.username} IS READY !!`))
  client.user.setPresence({
    activities: [
      {
        name: config.status,
        type: Discord.ActivityType.Streaming,
        url:config.url,
      }
    ],
    status: 'streaming'
  });

let guild = client.guilds.cache.get(config.guild)
  setInterval(() => {
joinVoiceChannel({
            channelId: config.voice,
            guildId: config.guild ,
            adapterCreator: guild.voiceAdapterCreator
        })
  },1000)
  
});



const autoline = [
  '1333850950980341922',
  '1301200753251323975',
  '1263153319531249836'
] // ايدي شات الخط تلقائي 

const line = 'https://cdn.discordapp.com/attachments/1274274403193978913/1333057208564318310/image.png?ex=679b7645&is=679a24c5&hm=94bb9422fe0bda57b5723bd66a379cf25defd34bc3e7925b4bdcdfc049705d22&'

  // Anti Crash - ما يخلي البوت يطفي لايرور بالكود

  

  client.on("messageCreate", venus => { 
    if (venus.content.startsWith(config.prefix + "نداء")) {

    if(!venus.member.roles.cache.some(r => r.id === config.staff)) return;

  let user = venus.mentions.users.first()

  if(!user) return venus.reply({content:"**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـنـداء بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**", embeds: [] });

      const args = venus.content.split(" ").slice(2).join(" ");
  user.send({
    embeds: [
      new EmbedBuilder()
        .setColor(config.color)
  .setTitle(`**__ <:Support:1254039304968339487> - ${venus.guild.name}__**`)
        .setDescription("**__ <:Support:1254039304968339487>  - عـزيـزي الـعـضـو .\n\n\ <a:GOLDEN12:1243477850095489027>   - تـم مـنـاداتـك مـن قـبـل الإداري يـرجـى الـذهـاب الـى الـشـات  .\n\n( وشـكـرآ لـك )__**")
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel(`- لـلـتـوجـه الـى  ${user.username}`)
          .setStyle('Link')
          .setURL(`https://discord.com/channels/${venus.guild.id}/${venus.channel.id}`)
      )
    ]
  });


      venus.reply({
        content: "-",
        embeds: [
          new EmbedBuilder()
            .setColor(config.color)
            .setDescription("**__ <:Support:1254039304968339487>  - عـزيـزي الإداري .\n\n <a:WIN:1243495579045068840>   - تـم مـنـادات الـعـضـو بـنـجـاح .\n\n( وشـكـرآ لـك )__**")
            .setThumbnail(venus.guild.iconURL({ dynamic: true }))
        ],
        components: []
      });
    }
  })

client.on('messageCreate', async message => {
    if (message.content === '-help') {
        const member = message.member;

        
        if (!member.roles.cache.has(config.owner)) {
            return;
        }

        
        const helpEmbed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`${message.guild.name}`)
            .setDescription(`__**<a:GOLDEN103:1243479197574500435>  – مـرحـبـاً بـك عـزيـزي الـعـضـو فـي كـشـف اوامـر الـبـوت .

<a:GOLDEN92:1243478920624345138>  – لـرؤيـة اوامـر الـبـوت قـم بـالـظـغـط عـلـى الـزر الـذي بـالاسـفـل .

<a:OGR:1243479816301445193>  – واخـتـر الـزر الـذي تـريـد كـشـف اوامـرة .

<a:GOLDEN12:1243477850095489027>  – وشـكـراً لـك .**__`);

        
        const row = new ActionRowBuilder()
            .addComponents(
                new SelectMenuBuilder()
                    .setCustomId('help_options')
                    .setPlaceholder('— choose the appropriate option .')
                    .addOptions([
                        {
                            label: '— الاوامر الـعـامـة .',
                            description: '— لـرؤيـة الاوامـر الـعـامـة .',
                            value: 'option_1',
                        },
                        {
                            label: '— اوامـر الـتـذاكـر .',
                            description: '— لـرؤيـة اوامـر الـتـذاكـر كـامـلـة .',
                            value: 'option_2',
                        },
                        {
                            label: '— الاوامـر الآخـرى .',
                            description: '— لـرؤيـة بـاقـي الاوامـر .',
                            value: 'option_3',
                        },
                    ]),
            );

        const sentMessage = await message.reply({ embeds: [helpEmbed], components: [row] });

        //   ٦٠ ثانية  
        const collector = sentMessage.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', interaction => {
            if (!interaction.isSelectMenu()) return;
            
            if (interaction.customId === 'help_options') {
                let replyMessage;
                switch (interaction.values[0]) {
                    case 'option_1':
                        replyMessage = `**__   
<a:Eror6:1258864603497238529>  – الاوامـر الـعـامـة .

<:Support:1254039304968339487>  – الـتـفـعـيـل 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -تـفـعـيـل )

<:Support:1254039304968339487>  – الاقـيـام . 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -قـيـم )

<:Support:1254039304968339487>  – الـسـجـن وفـك الـسـجـن . 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -سـجـن )

<:Support:1254039304968339487>  – الـتـوظـيـف . 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -تـوظـيـف )

<:Support:1254039304968339487>  – الـتـقـاعـد . 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -تـقـاعـد )

<:Support:1254039304968339487>  – . الـمـنـح 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -مـنـح )

<:Support:1254039304968339487>  – . الـتـصـفـيـر 

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -تـصـفـيـر )

<:Support:1254039304968339487>  – . تـصـفـيـر الـجـمـيـع

<a:Eror6:1258864603497238529> – الامـر بـيـن قـوسـيـن ( -تـصـفـيـر-الـكـل )

__**`;
                        break;
                    case 'option_2':
                        replyMessage = `__<a:Eror6:1247718148866838528>   – اوامـر الـتـذاكـر .

<a:i2heje2:1241145020552318979>  – تـذكـرة الـتـفـعـيـل 

<a:Eror6:1247718148866838528> – الامـر بـيـن قـوسـيـن ( -P1 )

<a:i2heje2:1241145020552318979> – تـذكـرة الـمـسـاعـدة و الـشـكـاوي   

<a:Eror6:1247718148866838528> – الامـر بـيـن قـوسـيـن ( -P2 )

<a:i2heje2:1241145020552318979> – تـذكـرة اونـر . 

<a:Eror6:1247718148866838528> – الامـر بـيـن قـوسـيـن ( -P3 )

 __`;
                        break;
                    case 'option_3':
                        replyMessage = `Soon`;
                        break;
                }
                interaction.reply({ content: replyMessage, ephemeral: true });
            }
        });

        collector.on('end', collected => {
            row.components[0].setDisabled(true);
            sentMessage.edit({ components: [row] });
        });
    }
});


  client.on('messageCreate', async wolf => {
  if (wolf.content === config.prefix + "ضبط") {

    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setTitle(`${wolf.guild.name}`) 
      .setDescription(`**__ <a:7235online:1252849477430022144> — بـيـانـات الـخـادم

<a:Alert:1247718395202502796> — لإعـادة ضـبـط بـيـانـات الـتـذاكر يـُـمـكـنـك الـضـغـط عـلـى الـخّـيـار أدنـاه 

( مـع تـمـنـيـاتـنـا بـالـتـوفـيـق ).__**`);

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('reset-tickets')
      .setPlaceholder('— choose the appropriate option .')
      .addOptions([
        {
          label: '— Reset Data .',
          description: '— لإعـادة ضـبـط بـيـانـات الـتـذاكـر .',
          emoji: `<a:Alert:1247718395202502796>`,
          value: 'reset_data',
        }
      ]);

    const row = new ActionRowBuilder().addComponents(selectMenu);

    wolf.channel.send({ embeds: [embed], components: [row] });
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;

  if (interaction.customId === 'reset-tickets') {
    if (!interaction.member.roles.cache.has(config.owner)) {
      return interaction.reply({ content: '**__ <a:Alert:1247718395202502796> — لا تـمـتـلـك الـصـلاحـيـات الـكـافـيـة لآسـتـعـمـال الآمـر.__**', ephemeral: true });
    }

    if (interaction.values[0] === 'reset_data') {
      interaction.guild.members.cache.forEach(async member => {
        db2.delete(`ticu2_${member.id}`);
        db2.delete(`ticu_${member.id}`);
      });

      interaction.guild.channels.cache.forEach(async channel => {
        db2.delete(`tic2_${channel.id}`);
        db2.delete(`uuu2_${channel.id}`);
        db2.delete(`msg2_${channel.id}`);
        db2.delete(`ticcc2_${channel.id}`);
        db2.delete(`tic_${channel.id}`);
        db2.delete(`uuu_${channel.id}`);
        db2.delete(`msg_${channel.id}`);
        db2.delete(`ticcc_${channel.id}`);
      });

      interaction.reply({ content: '**__ <a:GOLDEN12:1243477850095489027> — تـم إعـادة ضـبـط الـبـيـانـات.__**', ephemeral: true });

      const logChannel = interaction.guild.channels.cache.get(config.log99);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor(config.color)
          .setTitle(`${interaction.guild.name}`)
          .setDescription(`**__ <a:Alert:1247718395202502796> — خـدمـاتُ الـلـوق

<a:GOLDEN12:1243477850095489027> — قـام ${interaction.user} بـإعـادة ضـبـط بـيـانـات الـتـذاكـر__**`)
          .setTimestamp();

        logChannel.send({ embeds: [logEmbed] });
      }
    }
  }
});

  client.on('messageCreate',async wolf => {
    if(wolf.content.startsWith(config.prefix + "تصفير-نقاط")){

       if(!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

      let user = wolf.mentions.users.first()

      if(!user) return wolf.channel.send({content: "**__ <:Support:1254039304968339487>  - عـزيـزي الـمـسـؤول . \n\n<a:2d0466943bfa42319eb200b0b8ff60cc:1252851552675172394>  - يـرجـى الـتـأكـد مـن مـنـشـن الإداري الـمـرغـوب تـصـفـيـرة . \n\n ( وشـكـرآ لـك )__**"})

          let game = db2.get(`game_${user.id}`)
      let regs = db2.get(`regs_${user.id}`)
      let points = db2.get(`points_${user.id}`)
      let tickets = db2.get(`ptic_${user.id}`)
      let active = db2.get(`active_${user.id}`)
      let jobs = db2.get(`jobs_${user.id}`)
      let gmc = db2.get(`gmc_${user.id}`)


      if (!game) game = 0
      if (!regs) regs = 0
      if (!points) points = 0
      if (!tickets) tickets = 0
      if (!active) active = 0
      if (!jobs) jobs = 0
  if (!gmc) gmc = 0
      let total = parseInt(game) + parseInt(regs) + parseInt(points) + parseInt(tickets) + parseInt(active) + parseInt(jobs)


      wolf.channel.send({content: `**__ <:Support:1254039304968339487>   - عـزيـزي الـمـسـؤول .

<a:GOLDEN12:1243477850095489027>   - تـم تـصـفـيـر جـمـيـع نـقـاط الإداري ( ${user} ) بـنـجـاح .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`})

      db2.delete(`game_${user.id}`)    
      db2.delete(`regs_${user.id}`)
      db2.delete(`ptic_${user.id}`)
      db2.delete(`active_${user.id}`)
      db2.delete(`jobs_${user.id}`)
      db2.delete(`points_${user.id}`)
   db2.delete(`gmc_${user.id}`)

    }
  })

client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith(config.prefix + "تصفير")) {
    if (!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

    let user = wolf.mentions.users.first();

    if (!user) return wolf.reply({ content: "**__ <a:Alert:1247718395202502796> — يـرجـى مـنـشـن الإداري .__**" });

    let total = ['game', 'regs', 'points', 'ptic', 'active', 'jobs'].reduce((sum, key) => {
      let value = db2.get(`${key}_${user.id}`) || 0;
      return sum + parseInt(value);
    }, 0);

    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setDescription(`**__  — عـزيـزي الـمـسـؤول

<a:Alert:1247718395202502796> — هـل أنـت مـتـأكـد مـن تـصـفـيـر ${total} نـقـطـة مـن الإداري ${user}?__**`);

    const confirmButton = new ButtonBuilder()
      .setCustomId('confirm')
      .setLabel('— Confirm .')
      .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel')
      .setLabel('— Cancel .')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder()
      .addComponents(confirmButton, cancelButton);

    const msg = await wolf.reply({ embeds: [embed], components: [row] });

    const filter = (interaction) => interaction.user.id === wolf.author.id;

    const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async interaction => {
      if (interaction.customId === 'cancel') {
        embed.setDescription(`**__ <a:Alert:1247718395202502796> — تـم إلـغـاء عـمـلـيـة الـتـصـفـيـر.__**`).setColor(config.color);
        await interaction.update({ embeds: [embed], components: [] });
        collector.stop();
      }

      if (interaction.customId === 'confirm') {
        const modal = new ModalBuilder()
          .setCustomId('resetReason')
          .setTitle('— تـفـاصـيـل الـتـصـفـيـر .')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('reason')
                .setLabel('— سـبـب الـتـصـفـيـر .')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            )
          );

        await interaction.showModal(modal);
      }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
      if (!interaction.isModalSubmit()) return;

      if (interaction.customId === 'resetReason') {
        const reason = interaction.fields.getTextInputValue('reason');

        let logChannel = wolf.guild.channels.cache.get(config.logpoint);
        const logEmbed = new EmbedBuilder()
          .setColor(config.color) 
          .setTitle(`${wolf.guild.name}`)
          .setDescription(`**__  — خـدمـاتُ الـلوق

 — قـام ${wolf.author} بـعـمـلـيـة تـصـفـيـر إداريـة

<a:Alert:1247718395202502796> — الأداري الـذي تـم تـصـفـيـره : ${user}

 <a:7235online:1252849477430022144> — سـبـب الـتـصـفـيـر : ${reason}__**`);

        if (logChannel) {
          logChannel.send({ embeds: [logEmbed] });
        }

        const userEmbed = new EmbedBuilder()
          .setColor(config.color) 
          .setTitle(`${wolf.guild.name}`)
          .setDescription(`**__ <a:7235online:1252849477430022144> — مـرحـبـاً عـزيـزي

<a:7235online:1252849477430022144> — تـم تـصـفـيـر ${total} نـُـقـطـة مـن نـقـاطـك مـن قـبـل ${wolf.author}

<a:Alert:1247718395202502796> — سـبـب الـتـصـفـيـر : ${reason}__**`);

        try {
          await user.send({ embeds: [userEmbed], content: `${user}` });
        } catch (err) {
          console.log(`لم أتمكن من إرسال الرسالة لخاص ${user.tag}`);
        }

        ['game', 'regs', 'points', 'ptic', 'active', 'jobs','gmc'].forEach(key => {
          db2.delete(`${key}_${user.id}`);
        });

        embed.setDescription(`**__ <a:Alert:1247718395202502796> — تـم الإنـتـهـاء مـن عـمـلـيـة تـصـفـيـر ${total} نـقـطـة مـن الإداري ${user} بـنـجـاح .__**`).setTitle(`${interaction.guild.name}`)
          .setColor(config.color);
        await interaction.update({ embeds: [embed], components: [] });
        collector.stop();
      }
    });

    collector.on('end', async collected => {
      if (collected.size === 0) {
        embed.setDescription("**__<a:Alert:1247718395202502796> — تـم إلـغـاء الـعـمـلـيـة بـسـبـب عـدم الـتـفـاعـل.__**")
          .setTitle(`${wolf.guild.name}`)
          .setColor(config.color);
        await msg.edit({ embeds: [embed], components: [] });
      } else if (msg.editable) {
        await msg.edit({ components: [] });
      }
    });
  }
});

  client.on('messageCreate', async wolf => { if (wolf.content.startsWith(config.prefix + 'توظيف')) {

  if(!wolf.member.roles.cache.some(r => r.id === config.staff4)) return;

      const EMBED = new Discord.EmbedBuilder()
        .setThumbnail(wolf.guild.iconURL())
        .setDescription(`**__   - لائـحـة الـتـوظـيـف الـتـلـقـائـي <a:GOLDEN12:1243477850095489027>  .

  - لـتـفـعـيـل عـضـو فـي الـسـيـرفـر .
( -تفعيل )

  - لـسـجـن عـضـو مـخـالـف للـقـوانـيـن .
( -سجن ) 

  - لـتـوظـيـف عـضـو فـي الامـن .
( -الامن )

  - لـتـوظـيـف عـضـو فـي الـقـوات الـتـدخـل .
( -قوات )

 
- لـتـوظـيـف عـضـو فـي عـصـابـة  THE LAB .
( -LAB )
 
 - لـتـوظـيـف عـضـو فـي وزارة الـعـدل تـخـصص قـاضـي .
( -قاضي ) 

 - لـتـوظـيـف عـضـو فـي وزارة الـعـدل تـخـصص مـحـامـي .
( -محامي )
 

 - لـتـوظـيـف عـضـو فـي وزارة الإعـلام .
( -اعلام )

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق ) __**`)


  .setColor(config.color) 

  .setFooter({text: `Requested by ${wolf.author.tag}`, iconURL: wolf.author.displayAvatarURL({ dynamic: true })})

    /*
    let but1 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("Hello")
    .setEmoji("🤗")
    .setURL("https://discord.com")

    let but2 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("hi")
    .setEmoji("🤐")
    .setURL("https://discord.com")
       const Invite = new Discord.ActionRowBuilder()
        .addComponents(but1)
        .addComponents(but2)
    */
      wolf.channel.send({ embeds: [EMBED] })
    }
  })

client.on('messageCreate', async wolf => { if (wolf.content.startsWith(config.prefix + 'اعلان')) {

  if(!wolf.member.roles.cache.some(r => r.id === config.staff4)) return;

      const EMBED = new Discord.EmbedBuilder()
        .setThumbnail(wolf.guild.iconURL())
        .setColor(config.color) 
        .setDescription(`**__ <a:00:1247718460780445786>  -  تـم فـتـح الـتـفعـيـل فـي درع الـمـلـك

 <a:Alert:1247718395202502796>  -  قـبـل الـدخـول الـى الـتـفـعيل يـجـب عـلـيـك  ↓

<#1337115240457965618> 
<#1337115244031643678> 
<#1337115247110258698> 
<#1337115251497373778> 
<#1337115257554075819> 

 1 - قـراءة جـمـيـع الـقـوانـيـن الـموجـوده بالاعـلـى 

2 - تـجـهـيـز أيـديـك وتـجـهـيـز نـفـسـك للأسـألة والـمـقـابـلـة .
   
   

<a:7235online:1252849477430022144>  - نـتـمـنى لـكـم اجـتـيـاز الـمـقـابـلـة دون أيــ مـشـاكـل 
  
<a:7235online:1252849477430022144>  - We hope you pass the interview without any problems.

- وفـقـكـم الـلَّـه  .
<@&1337115114712862732>  

- 𝗞𝗶𝗻𝗚 𝗦𝗛𝗘𝗟𝗗 

https://discord.com/channels/1212381269653200936/1337115275975331911
__**`)


    /*
    let but1 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("Hello")
    .setEmoji("🤗")
    .setURL("https://discord.com")

    let but2 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("hi")
    .setEmoji("🤐")
    .setURL("https://discord.com")
       const Invite = new Discord.ActionRowBuilder()
        .addComponents(but1)
        .addComponents(but2)
    */
      wolf.channel.send({ embeds: [EMBED] })
    }
  })

  ///التوضيففف

  client.on('messageCreate', async wolf => {

    if (wolf.content.startsWith(config.prefix + "الامن")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

       if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content:"**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless3.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless3;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })

  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -الامـن للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)

    } else if (wolf.content.startsWith(config.prefix + "قوات")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless2.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless2;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -الـتـدخـل للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "MOXD")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless1.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless1;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر -MOXD للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)




    } else if (wolf.content.startsWith(config.prefix + "LAB")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless4.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless4;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر -LAB للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "القتسوءنسنصاروف")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:NorthCity:1240325004407734272>– عـزيـزي الإداري . \n\n <a:Weareded:1236853112036261889> - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless5.includes(r.id))) return wolf.channel.send({ content: "**__ <:NorthCity:1240325004407734272> – عـزيـزي الإداري . \n\n <a:Weareded:1236853112036261889> - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless5;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:NorthCity:1240325004407734272> – عـزيـزي الإداري .

  <a:emoji_8:1236852378532053072> - تـم تـوظـيـف الـعـضـو بـنـجـاح .
  - ${user} .
  ( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__<:pp449:1243650189944684745> – لـقـد قـام الادمـن :  ${wolf.author}

  <a:Weareded:1236853112036261889> – بـإسـتـعـمـال امـر  -القروف للـعـضـو :  ${user}

  <a:emoji_8:1236852378532053072> – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "قاضي")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless6.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless6;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -قـاضـي للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "محامي")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless7.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless7;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -مـحـامـي للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__<:pp449:1243650189944684745> – لـقـد قـام الادمـن :  ${wolf.author}

  <a:Weareded:1236853112036261889> – بـإسـتـعـمـال امـر  - للـعـضـو :  ${user}

  <a:emoji_8:1236852378532053072> – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

    } else if (wolf.content.startsWith(config.prefix + "ممممم")) {

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless8.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless8;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -مـكـافـحـة للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "محقق")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless9.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless9;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -مـحـقـق للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "اعلام")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless10.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless10;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
  let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر  -اعـلام\ي للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    } else if (wolf.content.startsWith(config.prefix + "ببببب")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff7)) return;

       if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:00:1247718460780445786>   - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـوظـيـف بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)

      if (u.roles.cache.some(r => config.roless11.includes(r.id))) return wolf.channel.send({ content: "**__<:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n  <a:rb_red:1243479487325274113>  - الـعـضـو مـوظـف بـالـفـعـل بـالـوظـيـفـة الـمـرغـوبـة . \n\n ( وشـكـرآ لـك )__**" })

      let roles = config.roless11;

      roles.forEach(async r => {
        u.roles.add(r)
      })

      db2.add(`jobs_${wolf.author.id}`, 1)

      wolf.channel.send({ content: `**__ <:Support:1254039304968339487>  – عـزيـزي الإداري .

<a:GOLDEN12:1243477850095489027>  - تـم تـوظـيـف الـعـضـو بـنـجـاح .
- ${user} .
( وشـكـرآ لـك )__**` })
let log = client.channels.cache.get(config.log0)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – لـقـد قـام الادمـن :  ${wolf.author}

   <a:WIN:1243495579045068840>  – بـإسـتـعـمـال امـر -قـنـاة للـعـضـو :  ${user}

   <a:GOLDEN12:1243477850095489027>  – وتـم اضـافـة جـمـيـع الـرتـب بـنـجـاح__**`)
    }

  })



  //رقابه
  client.on('messageCreate', async wolf => {

    if (wolf.content.startsWith(config.prefix + "gmc")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff8)) return;

       if (wolf.channel.id !== config.channel5) return;


   db2.add(`gmc_${wolf.author.id}`, 1)
      wolf.channel.send({ content: `**__ <a:GOLDEN12:1243477850095489027>  – انـت الآن رقـابـة فـي الـرحـلـة كـامـلـة

  <a:WIN:1243495579045068840>  – راجـع قـوانـيـن الـرقـابـة

  <a:GOLDEN12:1243477850095489027>  – رحـلـة مـمـتـعـة__**` })

  let log = client.channels.cache.get(config.log6)

                            if (!log) return;

                             log.send(`**__ <:Support:1254039304968339487>  – رقـابـي الـرحـلـة : ${wolf.author}

  <a:WIN:1243495579045068840>  – فـي حـال واجـهـت مـشـكـلـة تـوجـه لـه __**`)




                            log.send({ content: config.info })

      }

  })




  ///قسم التفعيل





  client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith(config.prefix + "تفعيل")) {

    if (!wolf.member.roles.cache.some(r => r.id === config.staff)) return;

    let user = wolf.mentions.users.first();
    if (!user) return wolf.reply({ content: "**__ <:Support:1254039304968339487>  - عـزيـزي الإداري .\n\n   <a:WIN:1243495579045068840>  - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـمـرغـوب تـفـعـيـلـة .\n\n ( وشـكـرآ لـك )__**" });

    let u = wolf.guild.members.cache.get(user.id);
    let data = db.get({ key: `data_${wolf.guild.id}` });
    let reason = db.get({ key: `reason_${user.id}` });

    if (!reason) reason = "لا يوجد سبب";

    if (db.has({ key: `data_${wolf.guild.id}` }) == true && data.includes(`id_${user.id}`)) {
      wolf.reply({
        content: `**__ <:Support:1254039304968339487>  - عـزيـزي الإداري .\n\n  <a:rb_red:1243479487325274113>  - لا يـمـكـنـك تـفـعـيـل هـذا الـعـضـو لـوجـودة فـي قـائـمـة الـسـجـنـاء .\n\n  - الـسـبـب : ${reason} .\n\n( وشـكـرآ لـك )__**`
      });
      u.roles.add(config.prison);
    } else {
      let name = wolf.content.split(' ').slice(2).join("-");
      if (!name) return wolf.reply({
        content: "**__ <:Support:1254039304968339487>  - عـزيـزي الإداري .\n\n   <a:00:1247718460780445786>   - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو أو كـتـابـة الأيـدي لـلـشـخـص الـمـرغـوب تـفـعـيـلـة .\n\n ( وشـكـرآ لـك )__**"
      });

      const confirmEmbed = new EmbedBuilder()
        .setColor(config.color)
        .setTitle(`${wolf.guild.name}`)
 .setDescription(`**__ <a:rb_red:1243479487325274113> — هـل انـت مـتـأكـد مـن كـتابـة آيـدي ${user} بـشـكـل صـحـيـح ودون أخـطـاء ، وهـل قـام بـقـراءة الـقـسـم.__**`);

      const confirmButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('confirmActivate')
            .setLabel('— Confirm .')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('cancelActivate')
            .setLabel('— Cancel .')
            .setStyle(ButtonStyle.Danger)
        );

      let confirmationMessage = await wolf.reply({ embeds: [confirmEmbed], components: [confirmButtons] });

      const filter = i => i.user.id === wolf.author.id;

      const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        if (i.customId === 'confirmActivate') {
          u.roles.add(config.act1);
          u.roles.add(config.act2);
          u.roles.remove(config.unact);
          u.setNickname(name);

          const logChannel = wolf.guild.channels.cache.get(config.log8);

          const logEmbed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`${wolf.guild.name}`)
            .setDescription(`**__  — خـدمـاتُ الـلوق
            
<a:rb_red:1243479487325274113> — قـام ${wolf.author} بـعـمـلـيـة تـفـعـيـل جـديـدة جـديـدة

<a:rb_red:1243479487325274113> — الـعـضـو الـذي تـم تـفـعـيـلـه : ${user}__**`)
            .setTimestamp();

         if (logChannel) logChannel.send({ embeds: [logEmbed] });

          const memberEmbed = new EmbedBuilder()
            .setTitle(`${wolf.guild.name}`)
            .setColor(config.color)
           .setDescription(`**__ <a:00:1247718460780445786>   - عـزيـزي الـعـضـو .


   <a:GOLDEN12:1243477850095489027>  - تـم تـفـعـيـلـك فـي سـيـرفـر ${wolf.guild.name}  للـحـيـاة الـواقـعـيـة نـرجـوا مـنـك الإلـتـزام بـالـقـسـم وبـجـمـيـع الـقـوانـيـن .

  ( Welcome to ${wolf.guild.name} )

  ( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق )__**`);

          const feedbackButtons = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('goodActivation')
                .setLabel('— تـعـامـل جـيـد .')
                .setStyle(ButtonStyle.Primary),
              new ButtonBuilder()
                .setCustomId('badActivation')
                .setLabel('— تـعـامـل سـيء .')
                .setStyle(ButtonStyle.Danger)
            );

          u.send({ embeds: [memberEmbed] });

          const updatedEmbed = EmbedBuilder.from(confirmEmbed)
            .setDescription(`**__ <a:rb_red:1243479487325274113> – عـزيـزي الإداري .\n\n <a:7235online:1252849477430022144> - تـم تـفـعـيـل الـعـضـو بـنـجـاح .\n\n- الـعـضـو : ${user}  .\n\n( وشـكـرآ لـك )__**`);
          await i.update({ embeds: [updatedEmbed], components: [] });
    db2.add(`active_${wolf.author.id}`, 1) 

        } else if (i.customId === 'cancelActivate') {
          const cancelEmbed = EmbedBuilder.from(confirmEmbed)
            .setDescription('**__ <a:rb_red:1243479487325274113> – عـزيـزي الإداري .\n\n <a:rb_red:1243479487325274113> - تـم إلـغـاء عـمـلـيـة الـتـفـعـيـل .\n\n( وشـكـرآ لـك )__**');
          await i.update({ embeds: [cancelEmbed], components: [] });
        }
      });

      collector.on('end', collected => {
        if (collected.size === 0) {
          const timeoutEmbed = EmbedBuilder.from(confirmEmbed)
            .setDescription('**__ <a:rb_red:1243479487325274113> — تـم إلـغـاء عـمـلـيـة الـتـفـعـيـل بـسـبـب عـدم الـتـفاعـل .__**');
          confirmationMessage.edit({ embeds: [timeoutEmbed], components: [] });
        }
      });
    }
  }
});


  client.on('messageCreate', async (message) => {
    if (message.content.startsWith(config.prefix + "سجن")) {

        if (!message.member.roles.cache.has(config.staff6)) return;

        let user = message.mentions.users.first();

        if (!user) {
            return message.reply({
                content: `**__ <:LL1:1271183148784422996> – عـزيـزي الإداري . 

<a:emoji_581:1271183239372865631>  -  يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـعـمـلـية بـالـشـكـل الـصـحـيـح .

 ( وشـكـرآ لـك )__**`
            });
        }

        const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`${message.guild.name}`)
            .setDescription(`**__ <:Support:1254039304968339487>  — خـدمـة الـسـجـن

<a:Alert:1247718395202502796>  — يـرجـى اخـتـيـار مـا تـحـتـاج تـطـبـيـقـه عـلـى ${user}.__**`);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('jail')
                    .setLabel('— سـجـن .')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('release')
                    .setLabel('— فـك الـسـجـن .')
                    .setStyle(ButtonStyle.Success)
            );

        const msg = await message.reply({ embeds: [embed], components: [row] });

        const filter = i => i.user.id === message.author.id && ['jail', 'release'].includes(i.customId);
        const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'jail') {
                let reason = message.content.split(' ').slice(2).join(" ") || "راجـع مـسـؤول المـخـالـفـيـن";
                let u = message.guild.members.cache.get(user.id);

                
                let roles = u.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.id);
                db.set(`roles_${user.id}`, roles);

            
                u.roles.cache.forEach(r => {
                    u.roles.remove(r.id);
                });
                u.roles.add(config.prison);

                db.push(`data_${message.guild.id}`, `id_${user.id}`);
                db.set(`reason_${user.id}`, reason);

                const jailEmbed = new EmbedBuilder()
                    .setColor(config.color)
                    .setTitle(`${message.guild.name}`) 
                    .setDescription(`**__ <a:7235online:1252849477430022144> — تـم سـجـن الـعـضـو بـنـجـاح.__**`)

                interaction.update({ embeds: [jailEmbed], components: [] });

                const logEmbed = new EmbedBuilder()
                    .setColor(config.color) 
                    .setTitle(`${message.guild.name}`) 
                    .addFields(
                        { name: 'العضو:', value: user.toString(), inline: true },
                        { name: 'السبب:', value: reason, inline: true },
                        { name: 'الإداري:', value: message.author.toString(), inline: true },
                    );

                message.guild.channels.cache.get(config.logprison).send({ embeds: [logEmbed] });

                const dmEmbed = new EmbedBuilder()
                    .setColor(config.color) 
                    .setTitle(`${message.guild.name}`) 
                    .setDescription(`**__ <a:00:1247718460780445786>  - عـزيـزي الـعـضـو .

<a:00:1247718460780445786> - تـم سـجـنـك لـعـدم الإلـتـزام بـالـقـوانـيـن .

<:pp300:1334157459216138301>  — الـسـبـب : ${reason}

<:Support:1254039304968339487>  — تـم سـجـنـك مـن قـبـل : ${message.author} .

( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق )__**`);

                u.send({ embeds: [dmEmbed] });

            } else if (interaction.customId === 'release') {
                let u = message.guild.members.cache.get(user.id);

                db.unpush(`data_${message.guild.id}`, `id_${user.id}`);
                db.delete(`reason_${user.id}`);
                u.roles.remove(config.prison);
                
                
                let roles = db.get(`roles_${user.id}`);
           if (roles && roles.length) {
                    roles.forEach(unact => {
                        u.roles.add(unact);
                    });
                }
                db.delete(`roles_${user.id}`);

                const releaseEmbed = new EmbedBuilder()
                    .setColor(config.color) 
                    .setTitle(`${message.guild.name}`) 
                    .setDescription(`**__ <a:7235online:1252849477430022144> — تـم فـك سـجـن الـعـضـو بـنـجـاح.__**`);

                interaction.update({ embeds: [releaseEmbed], components: [] });

                const logEmbed = new EmbedBuilder()
                    .setColor(config.color) 
                    .setTitle(`${message.guild.name}`) 
                    .addFields(
                        { name: 'العضو:', value: user.toString(), inline: true },
                        { name: 'الإداري:', value: message.author.toString(), inline: true },
                    );

                message.guild.channels.cache.get(config.logprison).send({ embeds: [logEmbed] });

                const dmEmbed = new EmbedBuilder()
                    .setColor(config.color)
                    .setTitle(`${message.guild.name}`)
                    .setDescription(`**__<a:7235online:1252849477430022144> - عـزيـزي الـعـضـو .

<a:7235online:1252849477430022144> - تـم فـك سـجـنـك مـن قـبـل الإداري : ${message.author} لآنـتـهـاء مـدة عـقـوبـتـك الـمـفـروضـة .

( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق )__**`);

                u.send({ embeds: [dmEmbed] });
            }
        });

        collector.on('end', collected => {
            if (!collected.size) {
                msg.edit({ components: [] });
            }
        });
    }
});


    client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith(config.prefix + "قيم")) {

    if (!wolf.member.roles.cache.some(r => r.id === config.staff2)) return;

    if (wolf.channel.id !== config.channel) return;


    let filter = (m => m.author.id === wolf.author.id)

    var q1;
    var q2;
    var q3;
    var q4;
    var q5;

    wolf.channel.send("- كـابـتـن الـطـائـرة .").then(async fox => {

      fox.channel.awaitMessages({
        filter: filter,
        max: 1
      }).then(collected => {

        q1 = collected.first().content;
        collected.first().delete()




fox.edit("- ايدي كـابـتـن الـطـائـرة .").then(async fox => {

          fox.channel.awaitMessages({
            filter: filter,
            max: 1
          }).then(collected => {

            q2 = collected.first().content;
            collected.first().delete()




fox.edit("- مـسـاعـد كـابـتـن الـطـائـرة .").then(async fox => {

              fox.channel.awaitMessages({
                filter: filter,
                max: 1
              }).then(collected => {

                q3 = collected.first().content;
                collected.first().delete()





fox.edit("- ايـدي مـسـاعـد الـكـابـتـن .").then(async fox => {

                  fox.channel.awaitMessages({
                    filter: filter,
                    max: 1
                  }).then(collected => {

                    q4 = collected.first().content;
                    collected.first().delete()

                    fox.edit("- مـوعـد ركـوب الـطـائـرة .").then(async fox => {

                      fox.channel.awaitMessages({
                        filter: filter,
                        max: 1
                      }).then(collected => {

                        q5 = collected.first().content;
                        collected.first().delete()

fox.edit("- مـوعـد إقـلاع الـطـائـرة .").then(async fox => {

                      fox.channel.awaitMessages({
                        filter: filter,
                        max: 1
                      }).then(collected => {

                        q6 = collected.first().content;
                        collected.first().delete()

                        fox.edit(`**تم الاعلان عن الرحلة في <#${config.log}>**`).then(async fox => {

          fox.delete({timeout: 5000})

                          let log = client.channels.cache.get(config.log)

                          if (!log) return;

                          
const game = new Discord.EmbedBuilder()

.setThumbnail(wolf.guild.iconURL({dynamic:true}))
.setColor(config.color)
.setTimestamp()
.setDescription(`**__ <a:00:1247718460780445786>  — إعـلان رحـلـة لـدولـة - 𝗞𝗜𝗡𝗚 𝗦𝗛𝗘𝗟𝗗 .


1 - كـابـتـن الـطـائـرة : ${q1} .

2 - أيـدي كـابـتـن الـطـائـرة : ${q2} .

3 - مـسـاعـد الـطـائـرة : ${q3} .

4 - أيـدي مـسـاعـد الـكـابـتـن : ${q4} .

5 - مـوعـد ركـوب الـطـائـرة : ${q5} .

6 - مـوعـد ركـوب الـطـائـرة : ${q6} .

<a:WIN:1243495579045068840>  - مـلاحـظـات مـهـمـة .

( 1 ) - يـرجـى عـدم إزعـاج الـكـابـتـن ومـسـاعـدة فـي الـخـاص أو الـشـات .

( 2 ) - إضـافـة كـابـتـن الـطـائـرة أو مـسـاعـدة .

( 3 ) - الـتـجـويـن عـلـى الـكـابـتـن أو مـسـاعـدة بـعـد إعـطـاء إذن الـتـجـويـن .

( 4 ) - عـدم فـتـح الـمـايـك فـي الإنـتـظـار وبـدايـة الـرحـلـة لـتـجـنـب إزعـاج الـركـاب .

<:GOLDEN86:1243479320132063274>  - فـي حـال عـدم مـعـرفـتـك كـيـفـيـة ركـوب الـطـائـرة تـوجـة إلـى <#1301200836474437653>  

.__**`)
            .setColor(config.color)
            .setImage(config.info)              
log.send({embeds:[game],content:`**@everyone - @here**`}).then(async fox => {
                            fox.react("<a:GOLDEN92:1243478920624345138>")
})
log.send({ content: config.line })

                          db2.add(`game_${wolf.author.id}`, 5)

                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })
      })
      })
      })
    })
  }
})
  client.on('messageCreate', async wolf => {
    if (wolf.content.startsWith(config.prefix + "اقلاع")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff2)) return;

      if (wolf.channel.id !== config.channel3) return;


      let filter = (m => m.author.id === wolf.author.id)

      var q1;
      var q2;
      var q3;
      var q4;
      var q5;

      wolf.channel.send("- مـوعـد الاقـلاع ؟").then(async fox => {

        fox.channel.awaitMessages({
          filter: filter,
          max: 1
        }).then(collected => {

          q1 = collected.first().content;
          collected.first().delete()




  fox.edit("- عـدد الـركـاب ").then(async fox => {

            fox.channel.awaitMessages({
              filter: filter,
              max: 1
            }).then(collected => {

              q2 = collected.first().content;
              collected.first().delete()




  fox.edit("- كـابـتـن الـطـائـره ؟").then(async fox => {

                fox.channel.awaitMessages({
                  filter: filter,
                  max: 1
                }).then(collected => {

                  q3 = collected.first().content;
                  collected.first().delete()





  fox.edit("- مـسـاعـد الـكـابـتـن   ؟").then(async fox => {

                    fox.channel.awaitMessages({
                      filter: filter,
                      max: 1
                    }).then(collected => {

                      q4 = collected.first().content;
                      collected.first().delete()

                      fox.edit("- عـدد الـرقـابـه  ").then(async fox => {

                        fox.channel.awaitMessages({
                          filter: filter,
                          max: 1
                        }).then(collected => {

                          q5 = collected.first().content;
                          collected.first().delete()



                          fox.edit(`**تم الاعلان عن التاكيد في <#${config.log2}>**`).then(async fox => {

            fox.delete({timeout: 5000})

                           let log2 = client.channels.cache.get(config.log2)

                          if (!log2) return;

                          
const game = new Discord.EmbedBuilder()

.setThumbnail(wolf.guild.iconURL({dynamic:true}))
.setColor(config.color)
.setTimestamp()
.setDescription(`**__ <a:00:1247718460780445786>  — إعـلان اقـلاع رحـلـه لـدولـة - 𝗞𝗜𝗡𝗚 𝗦𝗛𝗘𝗟𝗗  .


  1 - مــوعــد الاقـلاع : ${q1} 

  2 - عـدد الـركـاب   : ${q2} 

  3 - كـابـتـن الـطـائـره  : ${q3} 

  4 - مـسـاعـد كـابـتـن الـطـائـره   : ${q4} 

  5 -عـدد الـمـضـيـفـيـن  : ${q5} 


  - <a:Alert:1247718395202502796>  || مـلاحـظـات مـهـمـة .

  — فـي حـال واجـهـتـك مـشـكـلـةً مـا قـم بالـتـواصـل مـع الـمـنـظـمـيـن

  — فـي حـال واجـهـت مـخـرب او اي مـخـالـف رول بـلاي يـرجـى عـدم رد الـخـطـا بالـخـطـا وهــذا يـدخـلـك فـي الـمـشـكـلـه مـعـه بـل احـضـر الادلـة وارسـلـهـا لاي مـنـظـم او اونـر

  — الـرجـاء مـنـكـم مـراجـعـة جـمـيـع قـوانـيـن الـدولة لـتـجـنـب مـخـالـفـتـك

  — فـي حـال وجـود مـخـرب فـي الـقـيـم الـرجاء مـن الـجـمـيـع الـخـروج مـن الـقـيـم  .__**


  ||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||@here @everyone`)
.setColor(config.color)
.setImage(config.info)              
log2.send({embeds:[game],content:`**@everyone - @here**`}).then(async fox => {
                            fox.react("<a:GOLDEN92:1243478920624345138>")
})
log2.send({ content: config.line })

                            db2.add(`game_${wolf.author.id}`, 1)


                          })
                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })

      })
    }
  })



  client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith(config.prefix + "منح")) {

    if (!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

    let user = wolf.mentions.users.first();

    if (!user) return wolf.reply({ content: "**__ <a:Alert:1247718395202502796> — يـرجـى مـنـشـن الإداري .__**" });

    let points = wolf.content.split(' ')[2];

    if (!points) return wolf.reply({ content: "**__ <a:Alert:1247718395202502796> — يـرجـى كـتـابـة عـدد الـنـقـاط .__**" });

    if (isNaN(points)) return wolf.reply({ content: "**__ <a:Alert:1247718395202502796> — هـذا لـيـس عـدداً .__**" });

    let p = parseInt(points);

 reasonInputnfirmEmbed = new EmbedBuilder()
      .setTitle(`${wolf.guild.name}`)
      .setDescription(`**__ <a:7235online:1252849477430022144> — عـزيـزي الـمـسـؤول

<a:Alert:1247718395202502796> — هـل أنـت مـتـأكـد مـن مـنـح ${points} نـقـطـة إلـى الإداري ?__**`)
      .setColor(config.color);

    const confirmButton = new ButtonBuilder()
      .setCustomId('confirm_grant')
      .setLabel('— Confirm .')
      .setStyle(ButtonStyle.Success);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel_grant')
      .setLabel('— Cancel .')
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder()
      .addComponents(confirmButton, cancelButton);

    let confirmMessage = await wolf.reply({ embeds: [reasonInputnfirmEmbed], components: [row] });

    const filter = i => i.user.id === wolf.author.id;
    const collector = confirmMessage.createMessageComponentCollector({ filter, time: 15000 });

    collector.on('collect', async i => {
      if (i.customId === 'confirm_grant') {

        const modal = new ModalBuilder()
          .setCustomId('grant_reason')
          .setTitle('— تـفـاصـيـل الـمـنـح .');

        const reasonInput = new TextInputBuilder()
          .setCustomId('reason_input')
          .setLabel("— سـبـب الـمـنـح .")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);

        const modalRow = new ActionRowBuilder().addComponents(reasonInput);
        modal.addComponents(modalRow);

        await i.showModal(modal);
      }

      if (i.customId === 'cancel_grant') {
        await i.update({ content: '**__<a:Alert:1247718395202502796> — تـم إلـغـاء الـعـمـلـيـة.__**', components: [] });
      }
    });

    client.on('interactionCreate', async interaction => {
      if (interaction.type !== InteractionType.ModalSubmit) return;

      if (interaction.customId === 'grant_reason') {
        let reason = interaction.fields.getTextInputValue('reason_input');

        db2.add(`points_${user.id}`, p);

        const successEmbed = new EmbedBuilder()
          .setTitle(`${wolf.guild.name}`) 
          .setDescription(`**__<a:7235online:1252849477430022144> — تـم مـنـح ${points} إلـى ${user} بـنـجـاح.__**`)
          .setColor(config.color);

        await interaction.update({ embeds: [successEmbed], components: [] });

        const logChannel = client.channels.cache.get(config.logpoint);
        const logEmbed = new EmbedBuilder()
          .setTitle(`${wolf.guild.name}`) 
          .addFields(
            { name: 'الاداري:', value: `${user}`, inline: true },
            { name: 'عدد النقاط:', value: `${points}`, inline: true },
            { name: 'السبب:', value: reason, inline: false },
            { name: 'من قبل:', value: `${wolf.author}`, inline: true }
          )
          .setColor(config.color)
          .setTimestamp();

        logChannel.send({ embeds: [logEmbed] });

        const dmEmbed = new EmbedBuilder()
          .setTitle(`${wolf.guild.name}`) 
          .setDescription(`**__ <a:Alert:1247718395202502796> — مـرحـبـاً عـزيـزي

<a:Alert:1247718395202502796> — تـم مـنـحك ${points} بـنـجـاح مـن قـبـل ${wolf.author} 

 — سـبـب الـمـنـح : ${reason} __**`)
          .setColor(config.color);

        user.send({ embeds: [dmEmbed] }).catch(() => {
          wolf.reply({ content: "**__<a:Alert:1247718395202502796> — لـم اسـتـطـيـع ارسـال رسـالـة لـلإداري.__**" });
        });
      }
    });
  }
});





    client.on('messageCreate', async wolf => {
    if(wolf.content.startsWith(config.prefix + "تصفير-الكل")){

        if(!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

        const confirmationEmbed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`${wolf.guild.name}`)
            .setDescription('**__<a:Alert:1247718395202502796> — هـل انـت مـتـأكـد مـن أنـك تـريـد تـصـفـيـر نـقـاط الـجـمـيـع ، هـذه الـعـمـلـيـة لا يـمـكـن الـتـراجـع عـنـهـا .__**')
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirm_reset2')
                    .setLabel('— Confirm .')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('cancel_reset2')
                    .setLabel('— Cancel .')
                    .setStyle(ButtonStyle.Secondary),
            );

        const message = await wolf.reply({ embeds: [confirmationEmbed], components: [row] });

        const filter = i => i.user.id === wolf.author.id;
        const collector = message.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async i => {
            if (i.customId === 'confirm_reset2') {
                wolf.guild.members.cache.forEach(async member => {
                    db2.delete(`game_${member.id}`);    
                    db2.delete(`regs_${member.id}`);
                    db2.delete(`ptic_${member.id}`);
                    db2.delete(`active_${member.id}`);
                    db2.delete(`jobs_${member.id}`);
                    db2.delete(`points_${member.id}`);
                });

                const successEmbed = new EmbedBuilder()
                    .setColor(config.color)
                    .setTitle(`**__<a:7235online:1252849477430022144> — تـم تـأكـيـد عـمـلـيـة تـصـفـيـر الـكـل مـن ${wolf.author} بـنـجـاح .__**`)
                    .setTimestamp();

                await i.update({ embeds: [successEmbed], components: [] });

                const logChannel = wolf.guild.channels.cache.get(config.logpoint);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(config.color)
                        .setTitle(`${wolf.guild.name}`)
                        .setDescription(`**__  — خـدمـاتُ الـلوق

<a:7235online:1252849477430022144> — قـام ${wolf.author} بـعـمـلـيـة تـصـفـيـر نـقـاط الـكـل .__**`)
                        .setTimestamp();

                    logChannel.send({ embeds: [logEmbed] });
                }
            } else if (i.customId === 'cancel_reset2') {
                await i.update({ content: '**__<a:Alert:1247718395202502796> — تـم إلـغـاء عـمـلـيـة الـتـصـفـيـر .__**', embeds: [], components: [] });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.edit({ content: '**__ <a:Alert:1247718395202502796> — انـتـهـى الـوقـت ولـم يـتـم تـأكـيـد الـتـصـفـيـر.__**', embeds: [], components: [] });
            }
        });
    }
});

  client.on('messageCreate', async wolf => {
    if (wolf.content.startsWith(config.prefix + "yyy")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff3)) return;

      let user = wolf.mentions.users.first() 

      if (!user) user = wolf.author;

      let game = db2.get(`game_${user.id}`)
      let regs = db2.get(`regs_${user.id}`)
      let points = db2.get(`points_${user.id}`)
      let tickets = db2.get(`ptic_${user.id}`)
      let active = db2.get(`active_${user.id}`)
      let jobs = db2.get(`jobs_${user.id}`)
   let gmc = db2.get(`gmc_${user.id}`)

      if (!game) game = 0
      if (!regs) regs = 0
      if (!points) points = 0
      if (!tickets) tickets = 0
      if (!active) active = 0
      if (!jobs) jobs = 0
  if (!gmc) gmc = 0
      let total = parseInt(game) + parseInt(regs) + parseInt(points) + parseInt(tickets) + parseInt(active) + parseInt(jobs) + parseInt(gmc)


      const EMBED = new Discord.EmbedBuilder()
        .setThumbnail(wolf.guild.iconURL())
        .setDescription(`**__ <:Support:1254039304968339487>  - أهـلا بـك فـي درع الـمـلـوك للـنـقـاط الٱداريـة .

  <a:Alert:1247718395202502796>  - عـزيـزي الإداري نـقـاطـك الـحـالـيـة .

  1 - الـتـفـعـيـل : ( ${active} ) .

  2 - الـرحـلات : ( ${game} ) .

  3 - الـتـكـتـات : ( ${tickets} ) .

  4 - الـوظـائـف : ( ${jobs} ) .

  5 - الـتـقـاعـد : ( ${regs} ) .

  6 - الـرقـابـة : ( ${gmc} ) .

  7 - الأسـتـثـنـائـيـة : ( ${points} ) .

    - الأجـمـالـي : ( ${total} ) .__**`)

  .setColor(config.color) 

    /*
    let but1 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("Hello")
    .setEmoji("🤗")
    .setURL("https://discord.com")

    let but2 = new Discord.ButtonBuilder()
    .setStyle("5")
    .setLabel("hi")
    .setEmoji("🤐")
    .setURL("https://discord.com")
       const Invite = new Discord.ActionRowBuilder()
        .addComponents(but1)
        .addComponents(but2)
    */
      wolf.reply({ embeds: [EMBED]})
    }
  }) 


client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith(config.prefix + "hhhj")) {

    if (!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

    let user = wolf.mentions.users.first();

    if (!user) {
      const embed = new EmbedBuilder()
        .setColor(config.color)
        .setTitle(`${wolf.guild.name}`)
        .setDescription(`**__ <:Support:1254039304968339487> - 𝗞𝗜𝗡𝗚 𝗦𝗛𝗘𝗟𝗗  ManagemenT PointS .

<:Support:1254039304968339487> - مـركـز الـتـحـكـم لـكـشـف الـنُـقـاط الإداريـة .

<a:OGR:1243479816301445193>  - مـركـز كـشـف الـنـقـاط الإداريـة , هـو نـظـام أو وحـدة إداريـة تُـسـتـخـدم لـمُـتـابـعـة ورصـد الـنُـقـاط الإداريـة الـخـاصـة بـالـطـاقـم الإداري , يـهـدف إلـى تـسـجـيـل الـتـرقـيـات , الـعـقـوبـات , بـنـاء عـلـى مـعـايـيـر مُـحـددة .

<a:GOLDEN103:1243479197574500435> - الـقـيـادة الـعُـلـيـا  تـحـت خـدمـتـكـم دائـمـا , لـضـمـان الـنـظـام والـكـفـاءة فـي إدارة الـشـؤون الإداريـة . __**`);

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('show_self_points')
            .setLabel('— كـشـف نـقـاطـي .')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('show_other_points')
            .setLabel('— كـشـف الآخـريـن .')
            .setStyle(ButtonStyle.Secondary),
        );

      await wolf.channel.send({ embeds: [embed], components: [row] });
    }
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'show_self_points') {
    const user = interaction.user;

    let game = db2.get(`game_${user.id}`);
    let regs = db2.get(`regs_${user.id}`);
    let points = db2.get(`points_${user.id}`);
    let tickets = db2.get(`ptic_${user.id}`);
    let active = db2.get(`active_${user.id}`);
    let jobs = db2.get(`jobs_${user.id}`);
    let gmc = db2.get(`gmc_${user.id}`);

    if (!game) game = 0;
    if (!regs) regs = 0;
    if (!points) points = 0;
    if (!tickets) tickets = 0;
    if (!active) active = 0;
    if (!jobs) jobs = 0;
    if (!gmc) gmc = 0;

    let total = parseInt(game) + parseInt(regs) + parseInt(points) + parseInt(tickets) + parseInt(active) + parseInt(jobs) +  parseInt(gmc);

    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setTitle(`${interaction.guild.name}`)
      .setDescription(`**__ <:Support:1254039304968339487>  - أهـلا بـك فـي درع الـمـلـوك للـنـقـاط الٱداريـة .

  <a:Alert:1247718395202502796>  - عـزيـزي الإداري نـقـاطـك الـحـالـيـة .

  1 - الـتـفـعـيـل : ( ${active} ) .

  2 - الـرحـلات : ( ${game} ) .

  3 - الـتـكـتـات : ( ${tickets} ) .

  4 - الـوظـائـف : ( ${jobs} ) .

  5 - الـتـقـاعـد : ( ${regs} ) .

  6 - الـرقـابـة : ( ${gmc} ) .

  7 - الأسـتـثـنـائـيـة : ( ${points} ) .

    - الأجـمـالـي : ( ${total} ) .__**`);

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (interaction.customId === 'show_other_points') {
    const modal = new ModalBuilder()
      .setCustomId('user_points_modal')
      .setTitle('— خـدمـات الإدارة.');

    const userIdInput = new TextInputBuilder()
      .setCustomId('user_id_input')
      .setLabel("— آيـدي الـشـخـص .")
      .setStyle(TextInputStyle.Short);

    const row = new ActionRowBuilder().addComponents(userIdInput);
    modal.addComponents(row);

    await interaction.showModal(modal);
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'user_points_modal') {
    const userId = interaction.fields.getTextInputValue('user_id_input');
    const user = await client.users.fetch(userId);

    let game = db2.get(`game_${user.id}`);
    let regs = db2.get(`regs_${user.id}`);
    let points = db2.get(`points_${user.id}`);
    let tickets = db2.get(`ptic_${user.id}`);
    let active = db2.get(`active_${user.id}`);
    let jobs = db2.get(`jobs_${user.id}`);
    let gmc = db2.get(`gmc_${user.id}`);

    if (!game) game = 0;
    if (!regs) regs = 0;
    if (!points) points = 0;
    if (!tickets) tickets = 0;
    if (!active) active = 0;
    if (!jobs) jobs = 0;
    if (!gmc) gmc = 0;

    let total = parseInt(game) + parseInt(regs) + parseInt(points) + parseInt(tickets) + parseInt(active) + parseInt(jobs) +   parseInt(gmc);

    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setTitle(`${interaction.guild.name}`) 
      .setDescription(`**__ <:Support:1254039304968339487>  - أهـلا بـك فـي درع الـمـلـوك للـنـقـاط الٱداريـة .

  <a:Alert:1247718395202502796>  - ${user} عـزيـزي الإداري نـقـاط 
  1 - الـتـفـعـيـل : ( ${active} ) .

  2 - الـرحـلات : ( ${game} ) .

  3 - الـتـكـتـات : ( ${tickets} ) .

  4 - الـوظـائـف : ( ${jobs} ) .

  5 - الـتـقـاعـد : ( ${regs} ) .

  6 - الـرقـابـة : ( ${gmc} ) .

  7 - الأسـتـثـنـائـيـة : ( ${points} ) .

    - الأجـمـالـي : ( ${total} ) .__**`);

    await interaction.reply({ embeds: [embed], ephemeral: true });

  } 
  });

  //خطوط

client.on('messageCreate', async wolf => {
  if (wolf.content.startsWith("خط")) {
    wolf.delete()

    wolf.channel.send(config.line)
  }
})


client.on("messageCreate", async (message) => {
  if (message.content.startsWith("-رول")) {
    const args = message.content.split(" ").slice(1);
    let target = message.guild.members.cache.get(args[1]) || message.mentions.members.first();
    let role2 = await message.guild.roles.cache.get(config.staff);
    
    if (!message.member.roles.cache.has(role2.id) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;
    if (!target) return message.reply({ content: "**__  <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:WIN:1243495579045068840>  - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال إعـطـاء , إزالـة الـرتـبـة بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" });
    
    let role = message.guild.roles.cache.get(args[1]) || message.mentions.roles.first();
    if (!role) return message.reply({ content: "**__  <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:WIN:1243495579045068840>  - يـجـب عـلـيـك مـنـشـن الـرتـبـة أو وضـع ايـدي الـرتـبـة بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" });
    
    if (!target.roles.cache.some((r) => r.id === role.id)) {
      await target.roles.add(role);
      return message.reply({ content: `**__  <:Support:1254039304968339487>  – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>    - تـمـت عـمـلـيـة إعـطـاء الـرتـبـة  (\`${role.name}\`)  بـنـجـاح

<a:00:1247718460780445786>  - لـلـعـضـو : ${target} 

( وشـكـرآ لـك )__**` });
    } else {
      await target.roles.remove(role);
      return message.reply({ content: `**__  <:Support:1254039304968339487>  – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>    - تـمـت عـمـلـيـة إزالـة الـرتـبـة  (\`${role.name}\`)  بـنـجـاح

<a:00:1247718460780445786>  - لـلـعـضـو : ${target} 

( وشـكـرآ لـك )__**` });
    }
  }
});

  //التقاعد


client.on('messageCreate', message => {

if(message.author.bot) return;
  
  if (autoline.includes(message.channel.id)) { 
    
message.channel.send({ content:line});
}
})

  client.on('messageCreate', async wolf => {
    if (wolf.content.startsWith(config.prefix + "تقاعد")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.staff4)) return;

   if (wolf.channel.id !== config.channel2) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__  <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <a:WIN:1243495579045068840>  - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـتـقـاعـد بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })





      const select = new StringSelectMenuBuilder()
        .setCustomId('menu1')
        .setPlaceholder('- أخـتـر جـهـة الـتـقـاعـد .')
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel("- الـعـسـكـريـة .")
            .setDescription('- لـتـقـاعـد مـن الـعـسـكـريـة .')
            .setValue('opt1'),
          new StringSelectMenuOptionBuilder()
            .setLabel('- وزارة الـعـدل .')
            .setDescription('- لـتـقـاعـد مـن وزارة الـعـدل .')
            .setValue('opt2'),
          new StringSelectMenuOptionBuilder()
            .setLabel('- وزارة الإعـلام .')
            .setDescription("- لـتـقـاعـد مـن وزارة الإعـلام .")
            .setValue('opt3'),
          new StringSelectMenuOptionBuilder()
            .setLabel('- الـعـصـابـات .')
            .setDescription("- لـتـقـاعـد مـن الـعـصـابـات .")
            .setValue('opt4'),


        );

      let row = new Discord.ActionRowBuilder()
        .addComponents(select)

      let embed = new Discord.EmbedBuilder()

        .setTitle(`**${wolf.guild.name}**`)
        .setColor(config.color)
        .setDescription("**__  <:Support:1254039304968339487>  – عـزيـزي الإداري . \n\n  <:pp943:1274257655971446855>  - يـرجـى إخـتـيـار جـهـة الـتـقـاعـد مـن الـمـنـيـو أسـفـل الـرسـالـة .\n\n ( وشـكـرآ لـك ) __**")

      wolf.channel.send({ embeds: [embed], components: [row] }).then(async fox => {

        db2.set(`staff_${fox.id}`, wolf.author.id)
        db2.set(`user_${fox.id}`, user.id)
      })
    }
  })



  client.on('interactionCreate', async interaction => {

    if (!interaction.isSelectMenu()) return;

    if (interaction.values[0] === "opt1") {

      await interaction.deferUpdate()

      let user = db2.get(`user_${interaction.message.id}`)

      if (!user) return;

      if (interaction.user.id !== user) return;


      let admin = db2.get(`staff_${interaction.message.id}`)

      if (!admin) return;

      if (!interaction.member.roles.cache.some(r => config.roles1.includes(r.id))) return;


      let roles = config.roles1;

      roles.forEach(async r => {

        interaction.member.roles.remove(r)
      })

      interaction.message.delete()
      interaction.channel.send({ content: `**__ <:Support:1254039304968339487>   – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>  - تـم تـقـاعـد الـعـضـو بـنـجـاح .
-${interaction.user}  .

( وشـكـرآ لـك )__**`, ephemeral: false })


      db2.add(`regs_${admin}`, 1)
      db2.delete(`staff_${interaction.message.id}`)
      db2.delete(`user_${interaction.message.id}`)


    } else if (interaction.values[0] === "opt2") {

      await interaction.deferUpdate()

      let user = db2.get(`user_${interaction.message.id}`)

      if (!user) return;

      if (interaction.user.id !== user) return;


      let admin = db2.get(`staff_${interaction.message.id}`)

      if (!admin) return;

      if (!interaction.member.roles.cache.some(r => config.roles2.includes(r.id))) return;


      let roles = config.roles2;

      roles.forEach(async r => {

        interaction.member.roles.remove(r)
      })

      interaction.message.delete()
      interaction.channel.send({ content: `**__ <:Support:1254039304968339487>   – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>  - تـم تـقـاعـد الـعـضـو بـنـجـاح .
-${interaction.user}  .

( وشـكـرآ لـك )__**`, ephemeral: false })


      db2.add(`regs_${admin}`, 1)
      db2.delete(`staff_${interaction.message.id}`)
      db2.delete(`user_${interaction.message.id}`)


    } else if (interaction.values[0] === "opt3") {

      await interaction.deferUpdate()

      let user = db2.get(`user_${interaction.message.id}`)

      if (!user) return;

      if (interaction.user.id !== user) return;


      let admin = db2.get(`staff_${interaction.message.id}`)

      if (!admin) return;

      if (!interaction.member.roles.cache.some(r => config.roles3.includes(r.id))) return;


      let roles = config.roles3;

      roles.forEach(async r => {

        interaction.member.roles.remove(r)
      })

      interaction.message.delete()
      interaction.channel.send({ content: `**__ <:Support:1254039304968339487>   – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>  - تـم تـقـاعـد الـعـضـو بـنـجـاح .
-${interaction.user}  .

( وشـكـرآ لـك )__**`, ephemeral: false })


      db2.add(`regs_${admin}`, 1)
      db2.delete(`staff_${interaction.message.id}`)
      db2.delete(`user_${interaction.message.id}`)


    } else if (interaction.values[0] === "opt4") {

      await interaction.deferUpdate()

      let user = db2.get(`user_${interaction.message.id}`)

      if (!user) return;

      if (interaction.user.id !== user) return;


      let admin = db2.get(`staff_${interaction.message.id}`)

      if (!admin) return;

      if (!interaction.member.roles.cache.some(r => config.roles4.includes(r.id))) return;


      let roles = config.roles4;

      roles.forEach(async r => {

        interaction.member.roles.remove(r)
      })

      interaction.message.delete()
      interaction.channel.send({ content: `**__ <:Support:1254039304968339487>   – عـزيـزي الإداري .

 <a:GOLDEN12:1243477850095489027>  - تـم تـقـاعـد الـعـضـو بـنـجـاح .
-${interaction.user}  .

( وشـكـرآ لـك )__**`, ephemeral: false })


      db2.add(`regs_${admin}`, 1)
      db2.delete(`staff_${interaction.message.id}`)
      db2.delete(`user_${interaction.message.id}`)


    }

  })
client.on('messageCreate', async message => {
    if (!message.content.startsWith('اسم') || message.author.bot) return;

    const args = message.content.slice('اسم'.length).trim().split(/ +/);
    const member = message.mentions.members.first();
    const newName = args.slice(1).join(' ');
    let role2 = await message.guild.roles.cache.get(config.staff);

    if (!member) {
        return message.reply('**__يـرجـى ذكـر الـعـضـو__**');
    }

    if (!newName) {
        return message.reply('**__يـرجـى ذكـر الآسـم__**');
    }

    // إنشاء الأزرار
    const confirmButton = new ButtonBuilder()
        .setCustomId('confirm')
        .setLabel('تـأكـيـد')
        .setStyle(ButtonStyle.Primary);

    const addLogoButton = new ButtonBuilder()
        .setCustomId('addLogo')
        .setLabel('شـعـار الإدارة')
        .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder()
        .addComponents(confirmButton, addLogoButton);

    // إنشاء الرسالة المضمنة
    const embed = new EmbedBuilder()
        .setColor(config.color) 
        .setTitle(`${message.guild.name}`)
        .setDescription(`**__ — مـرحبـا بـك عـزيـزي الآداري 

— يـرجـى مـنـك الآخـتـيـار مـن الأزرار فـي الأسـفـل مُـبـتـغـاك

– تأكيد : لـوضـع الإسـم بـدون اي شـي إضـافـي

– شعار الادارة : لإضـافـة شـعـار الإدارة عـلـى الإسـم تـلـقـائـيـًا__**`);

    const confirmationMessage = await message.reply({
        embeds: [embed],
        components: [row]
    });

    // انتظار تفاعل المستخدم مع الأزرار
    const filter = interaction => {
        return interaction.isButton() && interaction.user.id === message.author.id;
    };

    const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 15000 });

    collector.on('collect', async interaction => {
        if (interaction.customId === 'confirm') {
            try {
                const oldName = member.displayName;
                await member.setNickname(newName);
                const updatedEmbed = new EmbedBuilder()
                    .setColor(config.color)
                    .setTitle(`${message.guild.name}`) 
                    .setDescription(`**__ <a:GOLDEN12:1243477850095489027> تـم تـغـيـيـر الإسـم بـنـجـاح

— الـشـخـص : ${member}

— الإسـم الـسـابـق : ${oldName}

— الإسـم بـعـد الـتـغـيـيـر : ${newName}

— هـل تـم إضـافـة شـعـار الآدارة :  غـيـر صـحـيـح__**`);
                await interaction.update({ embeds: [updatedEmbed], components: [] });
            } catch (error) {
                console.error(error);
                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle(`${message.guild.name}`)
                    .setDescription('<a:WIN:1243495579045068840> لـيـس لـدي إذن لـتـغـيـيـر لـقـب هـذا الـمـسـتـخـدم.');
                await interaction.update({ embeds: [errorEmbed], components: [] });
            }
        } else if (interaction.customId === 'addLogo') {
            const logo = 'ᴺᶜ〢'; // يمكنك تغيير الشعار هنا
            const newNameWithLogo = `${logo} ${newName}`;
            try {
                const oldName = member.displayName;
                await member.setNickname(newNameWithLogo);
                const updatedEmbed = new EmbedBuilder()
                    .setColor(config.color)
                    .setTitle(`${message.guild.name}`)
                    .setDescription(`**__ تـم تـغـيـيـر الإسـم بـنـجـاح

— الـشـخـص : ${member}

— الإسـم الـسـابـق : ${oldName}

— الإسـم بـعـد الـتـغـيـيـر : ${newNameWithLogo}

— هـل تـم إضـافـة شـعـار الآدارة :  نـعـم__**`);
                await interaction.update({ embeds: [updatedEmbed], components: [] });
            } catch (error) {
                console.error(error);
                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle(`${message.guild.name}`) 
                    .setDescription('<a:WIN:1243495579045068840> لـيـس لـدي إذن لـتـغـيـيـر لـقـب هـذا الـمـسـتـخـدم.');
                await interaction.update({ embeds: [errorEmbed], components: [] });
            }
        }
    });

    collector.on('end', collected => {
        if (!collected.size) {
            const timeoutEmbed = new EmbedBuilder()
                .setColor(0xFFA500)
                .setTitle(`${message.guild.name}`) 
                .setDescription('انتهى الوقت ولم يتم اختيار أي خيار.');
            confirmationMessage.edit({ embeds: [timeoutEmbed], components: [] });
        }
    });
}); 



client.on('messageCreate', async wolf => { 
    if (wolf.content.startsWith(config.prefix + "P2")) {
        if (!wolf.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        let channel = wolf.mentions.channels.first(); 
        if (!channel) channel = wolf.channel;

        let embed = new EmbedBuilder()
            .setColor('#f1d401')
            .setTitle(`**${wolf.guild.name} Ticket**`)
            .setDescription(`**__ <a:GOLDEN12:1243477850095489027> - الـدعـم الـفـنـي . \n\n > - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي الـدعـم الـفـنـي  <:Support:1254039304968339487>  .\n\n > - لـوجـود شـكـوى عـلـى أحـد الأعـضـاء يـرجـى ضـغـط زر الـشـكـاوي الـعـامـة <a:WIN:1243495579045068840> . \n\n - لـطـلـب خـدمـة أو وجـود إسـتـفـسـار لـديـك يـرجـى ضـغـط زر قـسـم المـسـاعـدة <a:GOLDEN103:1243479197574500435> . \n\n - ويـرجـى الإلـتـزام بـالـقـوانـيـن المـوضـحـة  <a:i2heje2:1241145020552318979>  .\n\n 1 - إحـتـرام الإداري .\n 2 - شـرح مـشـكـلـتـك بـالـتـفـصـيـل .\n 3 - عـدم إكـثـار المـنـشـن بـالـتـكـت .\n4 - تـوفـر الأدلـة الـكـافـيـة وإرفـاقـهـا بـالتـكـت . \n\n - نـرجـوا الإلـتـزام بـالـلائـحـة وعـدم مـخـالـفـتـهـا <a:GOLDEN12:1243477850095489027> . \n\n ( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق <a:OGR:1243480024150184026> )__**`)
            .setImage(config.info2); 

        let menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('ticket')
                .setPlaceholder('- أخـتـر نـوع الـتـذكـرة .')
                .addOptions(
                    {
                        label: "- قـسـم الـمـسـاعـدة .",
                        value: "ticket_1",
                        description: '- لـطـلـب خـدمـة يـرجـى ضـغـط زر قـسـم المـسـاعـدة .',
                        emoji: "<a:Alert:1247718395202502796>"
                    },
                    {
                        label: "- الـشـكـاوي الـعـامـة .",
                        value: "ticket_2",
                        description: '- لـطـلـب خـدمـة يـرجـى ضـغـط زر قـسـم الـشـكـاوي .',
                        emoji: "<a:Alert:1247718395202502796>"
                   },
                   {
                        label: '— إعـادة تـعـيـيـن.',
                        value: 'reset_option',                        
                        description: '— هـنا لـكـي تـعـيد تـعـيـين الـزر.',
                        emoji:'<a:i2heje2:1241145020552318979>'
}
                )
        ); 

        await wolf.channel.send({
            embeds: [embed],
            components: [menu]
        });
    }
});


client.on('interactionCreate', async (interaction) => {
    if (interaction.isSelectMenu()) {
        const { customId, values } = interaction;

        if (customId === 'ticket') {
            const selectedTicketType = values[0];
            let ticketName, categoryId;

            if (selectedTicketType === 'ticket_1') {
                ticketName = `مـسـاعـدة﹣${interaction.user.username}`;
                categoryId = config.cat;
            } else if (selectedTicketType === 'ticket_2') {
                ticketName = `شـكـاوي﹣${interaction.user.username}`;
                categoryId = config.cat2;
            }

            const role = interaction.guild.roles.cache.find(n => n.name === "@everyone");

          
    const channel = await interaction.guild.channels.create({
        name: ticketName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites: [
            {
                id: config.staff,
                allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel]
            },
            {
                id: role.id,
                deny: [PermissionsBitField.Flags.ViewChannel]
            },
            {
                id: interaction.user.id,
                allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.AttachFiles]
            }
        ]
    });


            await interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم فـتـح تـذكـرة ( ${channel} ) يـرجـى الـتـوجـة للـتـذكـرة لإنـهـاء طـلـبـك .__**`, ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__ <a:00:1247718460780445786>  - عـزيـزي الـعـضـو : ${interaction.user} .

<a:i2heje2:1241145020552318979>  - مـرحـبـآ بـك فـي قـسـم الـشـكـاوي , الـمـسـاعـدة يـرجـى مـنـك الإنـتـظـار حـتـى يـتـم إسـتـلام تـذكـرتـك مـن أحـد أفـراد طـاقـم الإدارة .

( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق <a:ArabShare_43:1243481448216793198>  )__**`);

            const buttonRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setStyle("Danger").setLabel("قــفــل الـتـذكـرة").setCustomId("close"),
                    new ButtonBuilder().setStyle("Primary").setLabel("إسـتـلام الـتـذكـرة").setCustomId("claim"),
                    new ButtonBuilder().setStyle("Secondary").setLabel("تـرك الـتـذكـرة").setCustomId("unclaim")
                );

            await channel.send({ embeds: [embed], components: [buttonRow] });
        }
    }

    if (interaction.isButton()) {
        const channel = interaction.channel;

        if (interaction.customId === "claim") {
            if (!interaction.member.roles.cache.some(r => r.id === config.staff)) return interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:SECRETOWN:1252851615208046623>  - غـيـر مـصـرح لـك بـأسـتـخـدام الأمـر الـتـالـي الأمـر فـقـط مـصـرح ل : <@${admin}> .

( وشـكـرآ لـك )__**`, ephemeral: true });

db2.add(`ptic_${interaction.user.id}`, 4)

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__  <a:WIN:1243495579045068840>   – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم إسـتـلام تـذكـرتـك حـالـيـآ مـن أحـد أفـراد طـاقـم الإدارة : ${interaction.user} .

( وشـكـرآ لـك لإنـتـظـارك )__**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "unclaim") {
            const adminId = db2.get(`tic_${channel.id}`);
            if (interaction.user.id !== adminId) return interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:SECRETOWN:1252851615208046623>  - غـيـر مـصـرح لـك بـأسـتـخـدام الأمـر الـتـالـي الأمـر فـقـط مـصـرح ل : <@${admin}> .

( وشـكـرآ لـك )__**`, ephemeral: true });

      db2.subtract(`ptic_${interaction.user.id}`, 4)

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__  <a:WIN:1243495579045068840>   – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم تـرك تـذكـرتـك حـالـيـآ أنـتـظـر أحـد أفـراد طـاقـم الإدارة : ${interaction.user} .

( وشـكـرآ لـك لإنـتـظـارك )__**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "close") {
            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setDescription(`**__ <:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n <a:GOLDEN12:1243477850095489027>  - سـيـتـم إغـلاق الـتـكـت خـلال ( 5 ) ثـوانـي . \n\n ( وشـكـرآ لـك )__**`);

            await channel.send({ embeds: [embed] });
            setTimeout(() => {
                channel.delete();


                db2.delete(`tic_${channel.id}`);
                db2.delete(`uuu_${channel.id}`);
                db2.delete(`msg_${channel.id}`);
                db2.delete(`ticcc_${channel.id}`);
            }, 5000);
        }
    }
});







  // تكت 2

 client.on('messageCreate', async wolf => {
    if (wolf.content.startsWith(config.prefix + "P1")) {
        if (!wolf.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        let channel = wolf.mentions.channels.first();
        if (!channel) channel = wolf.channel;

        let embed = new EmbedBuilder()
            .setColor('#f1d401')
            .setTitle(`**${wolf.guild.name} Ticket**`)
            .setDescription(`**__ <a:GOLDEN103:1243479197574500435>  - تـذكـرة تـفـعـيـل . \n\n   <a:rb_green:1243479446682337290>   - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي سـيـرفـر درع الـمـلـك . \n\n  - <a:GOLDEN12:1243477850095489027>  لـطـلـب تـفـعـيـل فـي سـيـرفـر درع الـمـلـك أضـغـط الـزر أسـفـل الإسـتـبـيـان . \n\n  - ويـرجـى الإلـتـزام بـالـقـوانـيـن المـوضـحـة <a:Alert:1247718395202502796>  .\n\n 1 - 1 — احـتـرام الاداري .  .\n2 - 2 — عـدم اكـثـار مـنـشـن \n3 -3 — عـدم الـتـأخـر فـي الـرد .\n4 - فـي مـخـالـفـة أحـدى الـقـوانـيـن مـيـوت سـاعـة <a:WIN:1243495579045068840>  . \n\n  - درع الـمـلـك  فـي خـدمـتـكـم . \n\n ( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق <a:ArabShare_43:1243481448216793198>  )__**`)
            .setImage(config.info33);

        let menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('ticket')
                .setPlaceholder('- أخـتـر نـوع الـتـذكـرة .')
                .addOptions(
                    {
                        label: "- قـسـم الـتـفـعـيـل .",
                        value: "ticket_3",
                        description: '- لـطـلـب خـدمـة يـرجـى ضـغـط زر قـسـم الـتـفـعـيـل .',
                        emoji: "<a:OGR:1243479816301445193>"
                    },
                    {
                        label: '— إعـادة تـعـيـيـن .',
                        emoji: '<a:OGR:1243479816301445193>',
                        value: '4',
                        description: '— هـنا لـكـي تـعـيد تـعـيـين الـزر.'
                    }
                )
        );

        await wolf.channel.send({
            embeds: [embed],
            components: [menu]
        });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isSelectMenu()) {
        const { customId, values } = interaction;

        if (customId === 'ticket') {
            const selectedTicketType = values[0];
            let ticketName, categoryId;

            if (selectedTicketType === 'ticket_3') {
                ticketName = `تـفـعـيـل﹣${interaction.user.username}`;
                categoryId = config.cat3;
            }

            const role = interaction.guild.roles.cache.find(n => n.name === "@everyone");

            const channel = await interaction.guild.channels.create({
                name: ticketName,
                type: ChannelType.GuildText,
                parent: categoryId,
                permissionOverwrites: [
                    {
                        id: config.staff,
                        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel]
                    },
                    {
                        id: role.id,
                        deny: [PermissionsBitField.Flags.ViewChannel]
                    },
                    {
                        id: interaction.user.id,
                        allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.AttachFiles]
                    }
                ]
            });

            await interaction.reply({ content: `**__ <a:WIN:1243495579045068840> – عـزيـزي الـعـضـو . <a:GOLDEN12:1243477850095489027> - تـم فـتـح تـذكـرة ( ${channel} ) يـرجـى الـتـوجـه للـتـذكـرة لإنـهـاء طـلـبـك .__**`, ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__ <a:00:1247718460780445786> - عـزيـزي الـعـضـو : ${interaction.user} . <a:i2heje2:1241145020552318979> - مـرحـبـآ بـك فـي قـسـم الـشـكـاوي ... (المحتوى) ... __**`);

            const buttonRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setStyle("Danger").setLabel("قــفــل الـتـذكـرة").setCustomId("close"),
                    new ButtonBuilder().setStyle("Primary").setLabel("إسـتـلام الـتـذكـرة").setCustomId("claim"),
                    new ButtonBuilder().setStyle("Secondary").setLabel("تـرك الـتـذكـرة").setCustomId("unclaim")
                );

            await channel.send({ embeds: [embed], components: [buttonRow] });
        }
    }

    if (interaction.isButton()) {
        const channel = interaction.channel;

        if (interaction.customId === "claim") {
            if (!interaction.member.roles.cache.some(r => r.id === config.staff)) {
                return interaction.reply({ content: `**__ <a:WIN:1243495579045068840> – عـزيـزي الـعـضـو . <a:SECRETOWN:1252851615208046623> - غـيـر مـصـرح لـك بـأسـتـخـدام الأمـر الـتـالـي ... __**`, ephemeral: true });
            }

db2.add(`ptic_${interaction.user.id}`, 4)

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__ <a:WIN:1243495579045068840> – عـزيـزي الـعـضـو . <a:GOLDEN12:1243477850095489027> - تـم إسـتـلام تـذكـرتـك ... __**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "unclaim") {
            const adminId = db2.get(`tic_${channel.id}`);
            if (interaction.user.id !== adminId) {
                return interaction.reply({ content: `**__ <a:WIN:1243495579045068840> – عـزيـزي الـعـضـو . <a:GOLDEN12:1243477850095489027> - تـم تـرك تـذكـرتـك ... __**`, ephemeral: true });
            }

      db2.subtract(`ptic_${interaction.user.id}`, 4)

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__ <a:WIN:1243495579045068840> – عـزيـزي الـعـضـو . <a:GOLDEN12:1243477850095489027> - تـم تـرك تـذكـرتـك ... __**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "close") {
            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setDescription(`**__ <:Support:1254039304968339487> – عـزيـزي الإداري . \n\n <a:GOLDEN12:1243477850095489027> - سـيـتـم إغـلاق الـتـكـت خـلال ( 5 ) ثـوانـي . \n\n ( وشـكـرآ لـك )__**`);

            await channel.send({ embeds: [embed] });
            setTimeout(() => {
                channel.delete();
                db2.delete(`tic_${channel.id}`);
                db2.delete(`ticu_${interaction.user.id}`);
                db2.delete(`uuu_${channel.id}`);
                db2.delete(`msg_${channel.id}`);
                db2.delete(`ticcc_${channel.id}`);
            }, 5000);
        }
    }
});



client.on('messageCreate', async wolf => { 
    if (wolf.content.startsWith(config.prefix + "P3")) {
        if (!wolf.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        let channel = wolf.mentions.channels.first(); 
        if (!channel) channel = wolf.channel;

        let embed = new EmbedBuilder()
            .setColor('#f1d401')
            .setTitle(`**${wolf.guild.name} Ticket**`)
            .setDescription(`**__ <a:GOLDEN103:1243479197574500435>  - تـذكـرة طـلـب الأونـرز . \n\n   <a:rb_green:1243479446682337290>   -  مـرحـبـآ بـك عـزيـزي الـعـضـو فـي سـيـرفـر درع الـمـلـك . \n\n  - <a:GOLDEN12:1243477850095489027>  لـطـلـب أونـر فـي سـيـرفـر درع الـمـلـك أضـغـط الـزر أسـفـل الإسـتـبـيـان . \n\n  - ويـرجـى الإلـتـزام بـالـقـوانـيـن المـوضـحـة <a:Alert:1247718395202502796>  .\n\n 1 - عـدم فـتـح الـتـذكـرة لـسـبـب لا يـخـص  .\n2 - فـي حـال لـديـك شـكـوى لـم تـحـل يـرجـى أرفـاق الأدلـة فـي الـتـذكـرة . \n3 - عـدم إكـثـار المـنـشـن بـالـتـكـت .\n4 - فـي مـخـالـفـة أحـدى الـقـوانـيـن مـيـوت سـاعـة <a:WIN:1243495579045068840>  . \n\n  - أونـريـة درع الـمـلـك  فـي خـدمـتـكـم . \n\n ( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق <a:ArabShare_43:1243481448216793198>  )__**`)
            .setImage(config.info4); 

        let menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('ticket')
                .setPlaceholder('- أخـتـر نـوع الـتـذكـرة .')
                .addOptions(
                    {
                        label: "- قـسـم الأونــرز .",
                        value: "ticket_4",
                        description: '- لـطـلـب خـدمـة يـرجـى ضـغـط زر قـسـم الأونــرز  .',
                        emoji: "<a:Alert:1247718395202502796>"
                    },
                    {  
                        label: '— إعـادة تـعـيـيـن .',
                        emoji:'<a:Alert:1247718395202502796>',
                        value: '4',
                        description: '— هـنا لـكـي تـعـيد تـعـيـين الـزر.'}
                )
        ); 

        await wolf.channel.send({
            embeds: [embed],
            components: [menu]
        });
    }
});


client.on('interactionCreate', async (interaction) => {
    if (interaction.isSelectMenu()) {
        const { customId, values } = interaction;

        if (customId === 'ticket') {
            const selectedTicketType = values[0];
            let ticketName, categoryId;

            if (selectedTicketType === 'ticket_4') {
                ticketName = `أونـر﹣${interaction.user.username}`;
                categoryId = config.cat4;
            }

            const role = interaction.guild.roles.cache.find(n => n.name === "@everyone");

          
    const channel = await interaction.guild.channels.create({
        name: ticketName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites: [
            {
                id: config.owner,
                allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel]
            },
            {
                id: role.id,
                deny: [PermissionsBitField.Flags.ViewChannel]
            },
            {
                id: interaction.user.id,
                allow: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.AttachFiles]
            }
        ]
    });


            await interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم فـتـح تـذكـرة ( ${channel} ) يـرجـى الـتـوجـة للـتـذكـرة لإنـهـاء طـلـبـك .__**`, ephemeral: true });

             const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__ <a:00:1247718460780445786>  - عـزيـزي الـعـضـو : ${interaction.user} .

<a:i2heje2:1241145020552318979>  - مـرحـبـآ بـك فـي قـسـم الأونــرز يـرجـى مـنـك الإنـتـظـار حـتـى يـتـم إسـتـلام تـذكـرتـك مـن أحـد أفـراد طـاقـم الإدارة .

( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق <a:ArabShare_43:1243481448216793198>  )__**`);

            const buttonRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setStyle("Danger").setLabel("قــفــل الـتـذكـرة").setCustomId("close3"),
                    new ButtonBuilder().setStyle("Primary").setLabel("إسـتـلام الـتـذكـرة").setCustomId("claim3"),
                    new ButtonBuilder().setStyle("Secondary").setLabel("تـرك الـتـذكـرة").setCustomId("unclaim3")
                );

            await channel.send({ embeds: [embed], components: [buttonRow] });
        }
    }

    if (interaction.isButton()) {
        const channel = interaction.channel;

        if (interaction.customId === "claim3") {
            if (!interaction.member.roles.cache.some(r => r.id === config.owner)) return interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:SECRETOWN:1252851615208046623>  - غـيـر مـصـرح لـك بـأسـتـخـدام الأمـر الـتـالـي الأمـر فـقـط مـصـرح ل : <@${admin}> .

( وشـكـرآ لـك )__**`, ephemeral: true });

            db2.set(`tic_${channel.id}`, interaction.user.id);

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__  <a:WIN:1243495579045068840>   – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم إسـتـلام تـذكـرتـك حـالـيـآ مـن أحـد أفـراد طـاقـم الإدارة : ${interaction.user} .

( وشـكـرآ لـك لإنـتـظـارك )__**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "unclaim3") {
            const adminId = db2.get(`tic_${channel.id}`);
            if (interaction.user.id !== adminId) return interaction.reply({ content: `**__ <a:WIN:1243495579045068840>  – عـزيـزي الـعـضـو .

<a:SECRETOWN:1252851615208046623>  - غـيـر مـصـرح لـك بـأسـتـخـدام الأمـر الـتـالـي الأمـر فـقـط مـصـرح ل : <@${admin}> .

( وشـكـرآ لـك )__**`, ephemeral: true });

            db2.delete(`tic_${channel.id}`);

            const embed = new EmbedBuilder()
                .setTitle(`**${interaction.user.username} Ticket**`)
                .setColor(config.color)
                .setDescription(`**__  <a:WIN:1243495579045068840>   – عـزيـزي الـعـضـو .

<a:GOLDEN12:1243477850095489027>  - تـم تـرك تـذكـرتـك حـالـيـآ أنـتـظـر أحـد أفـراد طـاقـم الإدارة : ${interaction.user} .

( وشـكـرآ لـك لإنـتـظـارك )__**`);

            await channel.send({ embeds: [embed] });
        } 
        else if (interaction.customId === "close3") {
            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setDescription(`**__ <:Support:1254039304968339487>   – عـزيـزي الإداري . \n\n <a:GOLDEN12:1243477850095489027>  - سـيـتـم إغـلاق الـتـكـت خـلال ( 5 ) ثـوانـي . \n\n ( وشـكـرآ لـك )__**`);

            await channel.send({ embeds: [embed] });
            setTimeout(() => {
                channel.delete();

                db2.delete(`tic_${channel.id}`);
                db2.delete(`ticu_${interaction.user.id}`);
                db2.delete(`uuu_${channel.id}`);
                db2.delete(`msg_${channel.id}`);
                db2.delete(`ticcc_${channel.id}`);
            }, 5000);
        }
    }
});   


  client.on('messageCreate', async wolf => {

    if (wolf.content.startsWith(config.prefix + "شعار")) {



      if (!wolf.member.roles.cache.some(r => r.id === config.staff )) return;

      let user = wolf.mentions.users.first()

      if (!user) return wolf.channel.send({ content: "**__ <:NorthCity:1240325004407734272> – عـزيـزي الإداري .\n\n <a:Weareded:1236853112036261889> - يـجـب عـلـيـك مـنـشـن الـعـضـو .\n\n ( وشـكـرآ لـك )__**" })

      let u = wolf.guild.members.cache.get(user.id)






      u.setNickname(`ᴺᶜ〢 ${u.nickname}`)

      wolf.channel.send({ content: "**__تـم تـنـفـيـذ الأمـر بـنـجـاح <a:emoji_8:1236852378532053072>__**" })

    }

  })



  client.on('messageCreate', async north => {

    if (north.content.startsWith(config.prefix + "اداري")) {


      if (!north.member.roles.cache.some(r => r.id === config.qobol)) return;

      let user = north.mentions.users.first()

      if (!user) return north.channel.send({ content: "**__ <:Support:1254039304968339487>  – عـزيـزي الـمـسـؤول . \n\n  <a:WIN:1243495579045068840>  - يـجـب عـلـيـك مـنـشـن الـعـضـو لأكـمـال الـقـبـول بـالـشـكـل الـصـحـيـح . \n\n ( وشـكـرآ لـك )__**" })

      let u = north.guild.members.cache.get(user.id)


        north.reply({
      content: `**__تـم تـنـفـيـذ الامـر <a:GOLDEN12:1243477850095489027> __**`,
      ephemeral: true
  });






        u.roles.add(config.instf)
        u.roles.add(config.instf2)
        u.roles.add(config.instf3)
        u.roles.add(config.instf5)
   u.setNickname(`ᴺᶜ〢 ${u.nickname}`)

        north.channel.send({
          content: `**__ <:Support:1254039304968339487>  – عـزيـزي الـمـسـؤول .

  <a:GOLDEN12:1243477850095489027>  - تـم قـبـول الـعـضـو بـنـجـاح .
  - ${user} .
  ( وشـكـرآ لـك )__**` })
        u.send({
          content: `**__ <a:00:1247718460780445786>  - عـزيـزي الـعـضـو .


  <:Support:1254039304968339487>  - تـم قـبـولك فـي ادارة نـايـت سـيـتـي للـحـيـاة الـواقـعـيـة نـرجـوا مـنـك الإلـتـزام بـالـقـسـم وبـجـمـيـع الـقـوانـيـن .

  ( Welcome to ${north.guild.name} )

  نـرجـو مـنك مـراجـعـة 

  <#1263153406026186795> 

  <#1263153416385859645> 

  <#1263153411776450584> 

  <#1263153418445262930> 


  ( مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق )__**` })



    }
            })

   client.on("messageCreate" , async(abo7med) => {
    if(abo7med.content == "hehesqa"){
      const Virtualembed = new EmbedBuilder()
                        .setDescription('**__<:notification:1239963004276310151> – اهـلاً  ، انـا الـبـوت الـخـاص بـخـادم نـايـت سـيـتـي ، لـدي ازرار بالاسـفـل مـجـعـولـة لـمـعـرفـة اوامـري بـشـكل واضـح__**')
                        .setColor(config.color);

      const VRL1 = new ButtonBuilder()
                        .setLabel('اوامـر الادارة')
                        .setCustomId('VRL1')
                        .setStyle('Primary')



      const row = new ActionRowBuilder().addComponents(VRL1)
       abo7med.reply({embeds : [Virtualembed] , components : [row]})
    }
  })


  client.on('interactionCreate' , async(Virtualhelp) => {
    if(Virtualhelp.customId == "VRL1"){
        Virtualhelp.reply({content : `**__<a:GOLDEN103:1243479197574500435> – الاوامـر الاداريـة فـي نـايـت سـيـتـي

  — لـمـعـرفـة اوامـر الـتـوظـيـف :  -توظيف

  — للتـقـاعـد مـن الـوظـيـفـة :  -تقاعد

  — لـتـفـعـيـل عـضـو :  -تفعيل (مـنـشـن الـعـضـو) (ايـدي الـعـضو) 

  —للإطـلاع عـلى الـنـقـاط الاداريـة :  -نقاط

  — لـسـجـن عـضـو :  -سجن

  — لـفـك الـسـجـن :  -فك

  — لإضـافـة شـعـار الادارة : -شعار

  — لـنـداء شـخـص : -نداء (مـنـشـن الـشـخـص)

  — لـفـتـح رحـلـة : -قيم__**` , ephemeral : true})

    }
  })



  client.on('messageCreate', async message => {
      if (message.content === '!help')
      {
          const selectMenu = new StringSelectMenuBuilder()
              .setCustomId('select')
              .setPlaceholder('Choose an option')
              .addOptions([
                  {
                      label: 'اوامـر الادارة',
                      description: 'لـمـعـرفـة اوامـر الادارة',
                      value: 'option_1',
                    emoji: '<:Support:1254039304968339487>', 
                  },
                {
                      label: 'Restart',
                      description: 'لاستـعـمـال خـيـار اوامـر الادارة مـرة اخـرى',
                      value: 'option_2',
                    emoji: '<a:GOLDEN103:1243479197574500435>', 
                 },
              ]);

          const row = new ActionRowBuilder()
              .addComponents(selectMenu);

          await message.reply({ content: 
  '**__<a:GOLDEN103:1243479197574500435> – اهـلاً  ، انـا الـبـوت الـخـاص بـخـادم نـايـت سـيـتـي ، لـدي ازرار بالاسـفـل مـجـعـولـة لـمـعـرفـة اوامـري بـشـكل واضـح__**', components: [row] });
      }
  });

  client.on('interactionCreate', async interaction => {
      if (!interaction.isStringSelectMenu()) return;

      if (interaction.customId === 'select') {
          let responseMessage;
          switch (interaction.values[0]) {
              case 'option_1':
                  responseMessage = `**__<a:GOLDEN103:1243479197574500435> – الاوامـر الاداريـة فـي نـايـت سـيـتـي

  — لـمـعـرفـة اوامـر الـتـوظـيـف :  -توظيف

  — للتـقـاعـد مـن الـوظـيـفـة :  -تقاعد

  — لـتـفـعـيـل عـضـو :  -تفعيل (مـنـشـن الـعـضـو) (ايـدي الـعـضو) 

  — للإطـلاع عـلى الـنـقـاط الاداريـة :  -نقاط

  — لـسـجـن عـضـو :  -سجن

  — لـفـك الـسـجـن :  -فك

  — لإضـافـة شـعـار الادارة : -شعار

  — لـنـداء شـخـص : -نداء (مـنـشـن الـشـخـص)

  — لـفـتـح رحـلـة : -قيم

  — لـفـحـص الـركـاب : -فحص

  — لإقـلاع الـطـائـرة : -اقلاع__**`;
                 break;
            case 'option_2': 
             responseMessage = `<a:GOLDEN103:1243479197574500435>` 
             break;     
              default:
                  responseMessage = 'Unknown selection.';
          }
          await interaction.reply({ content: responseMessage, ephemeral: true });
      }
  });



  client.on('messageCreate', async wolf => {

    if (wolf.content.startsWith(config.prefix + "سحب")) {

      if (!wolf.member.roles.cache.some(r => r.id === config.owner)) return;

      let user = wolf.mentions.users.first();

      if (!user) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  - عـزيـزي الـمـسـؤول .\n\n   <a:WIN:1243495579045068840>  - .يـرجـى الـتـأكـد مـن مـنـشـن الإداري الـمـرغـوب سـحـبـه . \n\n ( وشـكـرآ لـك )__**" });

      let points = wolf.content.split(' ')[2];

      if (!points) return wolf.channel.send({ content: "**__ <:Support:1254039304968339487>  - عـزيـزي الـمـسـؤول . \n\n  <a:WIN:1243495579045068840>  - يـرجـى الـتـأكـد مـن عـدد الـنـقـاط الـمـرغـوبـة الـمـسـحـوبـة . \n\n ( وشـكـرآ لـك )__**" });

      if (isNaN(points)) return wolf.channel.send({ content: "**__<:Support:1254039304968339487> - عـزيـزي الـمـسـؤول \n\n<a:WIN:1243495579045068840> - يـرجـى الـتـأكـد مـن تـحـديـد الـنـقـاط الـمـسـحـوبـة . \n\n( وشـكـرآ لـك )__**" });

      let p = parseInt(points);

      // احصل على النقاط الحالية للمستخدم
      let currentPoints = db2.get(`points_${user.id}`) || 0;

      // قم بخصم النقاط المحددة
      let newPoints = currentPoints - p;

      // قم بتحديث النقاط في قاعدة البيانات
      db2.set(`points_${user.id}`, newPoints);

      wolf.channel.send({ content:`**__ <:Support:1254039304968339487>  - عـزيـزي الـمـسـؤول .

<a:GOLDEN12:1243477850095489027>   - تـم سـحـب ( ${p} ) نـقـطـة للإداري ( ${user} ) بـنـجـاح .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**` });
    }



  });

  client.on('messageCreate', async wolf => {
    if (wolf.content.startsWith(config.prefix + "ايمبد") && wolf.member.roles.cache.some(r => r.id === config.owner)) {
      try {
        await wolf.delete();

        const filter = m => m.author.id === wolf.author.id;
        const fox = await wolf.channel.send("- اكتب ما تريده وأرفق الصورة إذا كنت ترغب");

        const collected = await wolf.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] });
        const q1 = collected.first().content;
        const q2 = collected.first().attachments.size > 0 ? collected.first().attachments.first().url : null;

        await collected.first().delete();
        await fox.delete();

        const EMBED = new Discord.EmbedBuilder()
          .setTitle(`**${wolf.guild.name}**`)
          .setDescription(q1 || "")
          .setColor(config.color);

        if (q2) EMBED.setImage(q2);

        await wolf.channel.send({ embeds: [EMBED] });
      } catch (err) {
        wolf.channel.send("لم يتم استلام الرسالة أو الصورة في الوقت المحدد.");
      }
    }
  });


   client.on(Events.MessageCreate, message => {
      if (message.content.startsWith(config.prefix +'تحكم')) {
          if (!message.member.roles.cache.has(config.staff9)) return;

          const oqdl = new ActionRowBuilder()
              .addComponents(
                  new ButtonBuilder()
                      .setCustomId('lock-oqdl')
                      .setLabel('Close')
                      .setStyle('Primary')
                      .setEmoji('1275453081173233755'),
                  new ButtonBuilder()
                      .setCustomId('unlock-oqdl')
                      .setLabel('Open')
                      .setStyle('Success')
                      .setEmoji('1275453200073494590')
              );

          const embed = new EmbedBuilder()
              .setColor(config.color)
              .setTitle("**<a:00:1247718460780445786>  — Night City — <a:00:1247718460780445786>**")
              .setThumbnail(message.guild.iconURL())
              .setDescription('** <a:i2heje2:1241145020552318979>  — يُـرجـى تـحـديــد إحــدى الـخـيــارات أدنــاه :**')
              .addFields(
                  { name: 'Close', value: '<:Close:1275453081173233755>', inline: true },
                  { name: 'Open', value: '<:Open:1275453200073494590>', inline: true }
              )
              .setFooter({ text: `All rights reserved to Night City Server`, iconURL: message.guild.iconURL({ dynamic: true }) });

          message.reply({
              embeds: [embed],
              components: [oqdl]
          }).then(sendMessage => {
              const collector = sendMessage.createMessageComponentCollector({ max: 1, time: 10000 });

              collector.on('collect', interaction => {
                  // Remove the buttons
                  sendMessage.edit({ components: [] });

                  if (!interaction.member.roles.cache.has(config.staff)) return;

                  if (interaction.customId === 'lock-oqdl') {
                      interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                          SendMessages: false
                      }).then(() => {
                          interaction.update({
                              content: '-',
                              embeds: [new EmbedBuilder()

                                  .setDescription(`**__لـقـد تـم إغـلاق الــشــات  <a:GOLDEN12:1243477850095489027>  .

  — يـمـنـع مـن الـلـذيـن يـملكـون صلاحـيـات الـكـتـابـه إلـى بـإذن مـن أحـد الـمـسؤولـيـيـن <a:WIN:1243495579045068840> .

  <:Support:1254039304968339487>  — لـقـد تـم قـفـل الــشـات مـن قـبـل : 
  \- <@${message.author.id}> __**`)
                                  .setColor(config.color)
                                  .setImage(config.line)]
                          });
                      }).catch(error => {
                          console.error('Failed to edit channel permissions:', error);
                      });
                  } else if (interaction.customId === 'unlock-oqdl') {
                      interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                          SendMessages: true
                      }).then(() => {
                          interaction.update({
                              content: '-',
                              embeds: [new EmbedBuilder()

                                  .setDescription(`**__لـقـد تـم فـتـح الــشــات  <a:GOLDEN12:1243477850095489027>  .

  — لـقـد تـم فـتـح الـشــات يـُمـكِـنــكـُـم الـتـكـلـم والـرجــاء عـدم الـتـكـلـم بالأمـور الـمـمـنـوعـة ويـجـب قـرائـة جـمـيـع الـ <#1263153267165364356>    . 

  <:Support:1254039304968339487> — لـقـد تـم فـتـح الـشـات مـن قـبـل : 
  \- <@${message.author.id}> __**`)
                                  .setColor(config.color)
                                  .setImage(config.line)]
                          });
                      }).catch(error => {
                          console.error('Failed to edit channel permissions:', error);
                      });
                  }
              });
          }).catch(error => {
              console.error('Failed to send reply:', error);
          });
      }
  });                   

   

    client.on(Events.MessageCreate, async (message) => {
        if (message.content === "!mm") {

            if (!message.member.roles.cache.some(r => r.id === config.owner)) return;
          
                 const row = new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('manage_points')
                        .setPlaceholder('اخـتـر الـخـيـار الـمـنـاسـب')
                        .addOptions([
                            { label: 'إضـافـة نـقـاط لـلـجـمـيـع', value: 'add_all', description: 'تـقـوم بـوضـع عـدد الـنـقـاط الـتـي يـعـطـيـهـا لـكـل الادارة' },
                            { label: 'إضـافـة نـقـاط لـشـخـص مـعـيـن', value: 'add_specific', description: 'تـقـوم بـوضـع ايـدي الاداري وعـدد الـنـقـاط' },
                            { label: 'تـصـفـيـر نـقـاط الـجـمـيـع', value: 'reset_all', description: 'يـقـوم بـتـصـفـيـر الـكـل' },
                            { label: 'تـصـفـيـر نـقـاط شـخـص مـعـيـن', value: 'reset_specific', description: 'تـضـع ايـدي الاداري لـ يـتـم تـصـفـيـر نـقـاطـه بـالـكـامـل' },
                            { label: 'إعـادة الـقـائـمـة', value: 'reset_menu', description: 'يـقـوم بـإعـادة الـقـائـمـة' }, // خيار إعـادة الـقـائـمـة
                        ]),
                );

            await message.reply({ content: 'إخـتـر حـالـة الـنـقـاط الـمـنـاسـبـة لـلإدارة :', components: [row] });
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isSelectMenu()) return;

        if (interaction.customId === 'manage_points') {
            const selectedValue = interaction.values[0];

            if (selectedValue === 'add_all') {
                const modal = new ModalBuilder()
                    .setCustomId('add_points_all')
                    .setTitle('إضـافـة نـقـاط لـلـجـمـيـع');

                const pointsInput = new TextInputBuilder()
                    .setCustomId('points_input')
                    .setLabel("أدخل عدد النقاط:")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const firstActionRow = new ActionRowBuilder().addComponents(pointsInput);
                modal.addComponents(firstActionRow);

                await interaction.showModal(modal);

            } else if (selectedValue === 'add_specific') {
                const modal = new ModalBuilder()
                    .setCustomId('add_points_specific')
                    .setTitle('إضـافـة نـقـاط لـشـخـص مـعـيـن');

                const userIdInput = new TextInputBuilder()
                    .setCustomId('user_id_input')
                    .setLabel("أدخل ID المستخدم:")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const pointsInput = new TextInputBuilder()
                    .setCustomId('points_input')
                    .setLabel("أدخل عدد النقاط:")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const firstActionRow = new ActionRowBuilder().addComponents(userIdInput);
                const secondActionRow = new ActionRowBuilder().addComponents(pointsInput);
                modal.addComponents(firstActionRow, secondActionRow);

                await interaction.showModal(modal);

            } else if (selectedValue === 'reset_all') {
                interaction.guild.members.cache.forEach(member => {
                    db2.delete(`points_${member.id}`);
                });

                await interaction.reply({ content: "تم تـصـفـيـر نـقـاط الـجـمـيـع.", ephemeral: true });

            } else if (selectedValue === 'reset_specific') {
                const modal = new ModalBuilder()
                    .setCustomId('reset_points_specific')
                    .setTitle('تـصـفـيـر نـقـاط شـخـص مـعـيـن');

                const userIdInput = new TextInputBuilder()
                    .setCustomId('user_id_input')
                    .setLabel("أدخل ID المستخدم:")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const firstActionRow = new ActionRowBuilder().addComponents(userIdInput);
                modal.addComponents(firstActionRow);

                await interaction.showModal(modal);

            } else if (selectedValue === 'reset_menu') {
                // إعادة عرض القائمة
                const row = new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('manage_points')
                            .setPlaceholder('اختر الخيار المناسب')
                            .addOptions([
                                { label: 'إضـافـة نـقـاط لـلـجـمـيـع', value: 'add_all', description: 'تـقـوم بـوضـع عـدد الـنـقـاط الـتـي يـعـطـيـهـا لـكـل الادارة' },
                                { label: 'إضـافـة نـقـاط لـشـخـص مـعـيـن', value: 'add_specific', description: 'تـقـوم بـوضـع ايـدي الاداري وعـدد الـنـقـاط' },
                                { label: 'تـصـفـيـر نـقـاط الـجـمـيـع', value: 'reset_all', description: 'يـقـوم بـتـصـفـيـر الـكـل' },
                                { label: 'تـصـفـيـر نـقـاط شـخـص مـعـيـن', value: 'reset_specific', description: 'تـضـع ايـدي الاداري لـ يـتـم تـصـفـيـر نـقـاطـه بـالـكـامـل' },
                                { label: 'إعـادة الـقـائـمـة', value: 'reset_menu', description: 'يـقـوم بـإعـادة الـقـائـمـة' }, // خيار إعـادة الـقـائـمـة
                            ]),
                    );

                await interaction.update({ content: 'إخـتـر حـالـة الـنـقـاط الـمـنـاسـبـة لـلإدارة :', components: [row] });
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'add_points_all') {
            const points = interaction.fields.getTextInputValue('points_input');
            const pointsInt = parseInt(points);

            if (isNaN(pointsInt)) {
                return interaction.reply({ content: 'يرجى إدخال عدد صحيح من النقاط.', ephemeral: true });
            }

            interaction.guild.members.cache.forEach(member => {
                db2.add(`points_${member.id}`, pointsInt);
            });

            await interaction.reply({ content: `تم إضافة ${pointsInt} نقطة للجميع.`, ephemeral: true });

        } else if (interaction.customId === 'add_points_specific') {
            const userId = interaction.fields.getTextInputValue('user_id_input');
            const points = interaction.fields.getTextInputValue('points_input');
            const pointsInt = parseInt(points);

            if (isNaN(pointsInt)) {
                return interaction.reply({ content: 'يرجى إدخال عدد صحيح من النقاط.', ephemeral: true });
            }

            const user = await client.users.fetch(userId).catch(() => null);

            if (!user) {
                return interaction.reply({ content: 'لم يتم العثور على المستخدم.', ephemeral: true });
            }

            db2.add(`points_${userId}`, pointsInt);
            await interaction.reply({ content: `تم إضافة ${pointsInt} نقطة للمستخدم ${user}.`, ephemeral: true });

        } else if (interaction.customId === 'reset_points_specific') {
            const userId = interaction.fields.getTextInputValue('user_id_input');
            const user = await client.users.fetch(userId).catch(() => null);

            if (!user) {
                return interaction.reply({ content: 'لم يتم العثور على المستخدم.', ephemeral: true });
            }

            db2.delete(`points_${userId}`);
            await interaction.reply({ content: `تم تصفير نقاط المستخدم ${user}.`, ephemeral: true });
        }
    });


client.on('messageCreate', async (message) => {
    if (message.content === '-rules') {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setThumbnail(message.guild.iconURL())
            .setTitle(`${message.guild.name}`)
            .setDescription(`**__ — الـقـــوانـيــن الـعــامـــة .__

>  — جـمـيــع الـقــواعـد و الـقـوانـيــن تـابـعــة لـخــادم نـايـت سـيـتـي
>
>  — يـوجـد زر لـمـن اراد مـعـرفـة الـقـوانـيـن و الانـظـمـة


 — يـجـب الإلـتــزام بـالـقــوانـيـن كـامـلــة .
**`);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('button1')
                    .setLabel('قـواعـد الـخـادم – Server Laws')
                    .setStyle(ButtonStyle.Secondary),
            );

        await message.channel.send({ embeds: [embed], components: [row] });
    }
});
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'button1') {
        const options = [
            { label: '— الـتـعـريـفـات الـعـامـة .', value: 'option1', emoji: `<a:OGR:1243479816301445193>`  },
            { label: '— الـقـوانـيـن الإجـرامـيـة .', value: 'option3', emoji: `<a:OGR:1243479816301445193>`  },
            { label: '— قـوانـيـن الـسـرقـات .', value: 'option4', emoji: `<a:OGR:1243479816301445193>`  },
            { label: '— قـوانـيـن الـرقـابـة .', value: 'option8', emoji: `<a:OGR:1243479816301445193>`  },
            { label: '— الـلـغـة الـعـامـة .', value: 'option9', emoji: `<a:OGR:1243479816301445193>`,  },
            { label: '— الـمـنـاطـق الآمـنـة .', value: 'option10', emoji: `<a:OGR:1243479816301445193>`  },
        ];

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('selectMenu1')
            .setPlaceholder('— Choose the law ...')
            .addOptions(options);

        const row = new ActionRowBuilder()
            .addComponents(selectMenu);

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`${interaction.guild.name}`)
            .setDescription('هـنـا يـمـكـنـك رؤيـة جـمـيـع الـقـواعـد.');

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isStringSelectMenu()) return;

    if (interaction.customId === 'selectMenu1') {
        const selectedOption = interaction.values[0];
        let response = '';

        switch (selectedOption) {
            case 'option1':
                response = `**__الـرول بـلاي : هـو تـقـمـص الـشـخـصـيـة بـالاقـوال و الافـعـال .

الـ RDM : الـقـتـل الـعـشـوائـي بـدون اي سـبـب .

الـ VDM : اسـتـخـدام الـمـركـبـة كسـلاح . 

الـ LAR : عـدم الـخـوف عـلـى حـيـاتـك و حـيـاة الاخـريـن .

الـحـاجـز الـسـمـعـي : عـدم سـمـاع شـخـص عـنـد وجـود حـاجـز او مـسـافـة طـويـلـة بـيـنـكـم .

الـقـانـون الـذهـبـي : عـدم رد الـخـطـأ بـالـخـطـأ .

تـعـريـف الـواقـعـيـة هـو : يـمـنـع قـتـل الـعـسـكـر داخـل المـديـنـة مـاعـدا الـمـنـاطـق الـغـيـر أمـنـة . 

- مـمـنـوع مـنـعا بـاتـاً سـرقـة الـسـيـارات الـعـسـكـريـة او الـحـكـومـيـة . 

- يـمـنـع اسـتـخـدام الـقـلـتـشـات ومـن ضـمـنـها الـمـلابـس الـمـهـكـرة .

- عـلـيـك تـقـمـص شـخـصـيـتـك داخـل الـسـيـرفـر و الـتـصـرف بـواقـعـيـة و عـدم الـخـروج عـن الرول بـلاي فـي أي ظـرف كـان 

@everyone __**`;
                break;
            case 'option3':
                response = `**
— قـوانـيـن الاجـرام <:gc1:1277180407707602999> 


على كل رجل عصابه معرفة ان التفتيش خارج المدينة يعتبر منطقة امنه لا يمكن التهديد فيها نهائيا

. يجب على كل رجل عصابة الاتزام بالانظمة العسكرية لانها سوف تحدث أنذار لجميع افراد العصابة

• لا يحق لك بعد الاعدام بالتقديم على اى وظيفة بجميع اشكالها الا بعد يوم كامل و عدم رفع الصوت على اي احد من منسوبي الوزارة

العسكرية او التلفظ علية

. على كل العصابات الحذر من الوقوع في مخالفة خارج نطاق الرول بلاي

. على كل عصابة احترام جميع الفئات في دولة سوا كان مواطن او ذو منصب عالي

. على كل رجل عصابة الالتزام بجميع قوانين السيرفر وقوانين الوزارات ولا يخالف اي قانون من قوانين الدولة

• يجب على اي عصابة في حال فعلهم سناريوا عدم التكلم اي شخص ماعادا التفاوض**
@everyone`;
                break;
            case 'option4':
                response = `***~~قوانين السرقات~~***


**سرقة البنك المركزي :**

**الحد الأدنى للسارقين 3**
**الحد الأقصى للسارقين8 **

**الحد الأدنى للعساكر 6**
**الحد الأقصى للعساكر 12**


**سرقة المرقص :**

**الحد الأدنى للسارقين 3**
**الحد الأقصى للسارقين 6**

**الحد الأدنى للعساكر 5**
**الحد الأقصى للعساكر 10**


**سرقة محل الملابس :**

**الحد الأدنى للسارقين 2**
**الحد الأقصى للسارقين 6**

**الحد الأدنى للعساكر 4**
**الحد الأقصى للعساكر 9**


**سرقة محل أسلحة :**

**الحد الأدنى للسارقين 3**
**الحد الأقصى للسارقين 6**

**الحد الأدنى للعساكر 4**
**الحد الأقصى للعساكر 9**


**سرقة ورشة :**

**الحد الأدنى للسارقين 2 **
**الحد الأقصى للسارقين 5**

**الحد الأدنى للعساكر 4**
**الحد الأقصى للعساكر 8**


**سرقة بقالة :**

**الحد الأدنى للسارقين 1**
**الحد الأقصى للسارقين 4**

**الحد الأدنى للعساكر 4**
**الحد الأقصى للعساكر 8**


**سرقة بيت :**

**الحد الأدنى للسارقين 3**
**الحد الأقصى للسارقين 6**


 || @everyone ||`;
                break;
            case 'option8':
                response = `__**1- اذا جاك الجمس الاسود تركب معاه بدون اي نقاش وتحاول تحل المشكله اللي صايرة لك

2- اذا جاك الجمس الاسود ضروري تتعاون معاه

3- اذا جاك الجمس الاسود ممنوع تتكلم الا اذا طلب منك

4- اذا جاك الجمس الاسود ممنوع مقاطعه الكلام  بين الطرفين

5- اذا جاك الجمس الاسود ممنوع تكذب وتقول الصدق دائما

6- اذا جاك الجمس الاسود ممنوع تهرب

7 - اذا جاك الجمس الاسود ممنوع تتفاعل معه الا اذا طلب منك او اذا شفته ممنوع تناديه او تقول ادمن

8- ممنوع تلحقه عليه باند**__`;
                break;
            case 'option9':
                response = `** — لـغـة الـسـيـرفـر 

شخص خارج عن الرول بلاي | سكران ، ماهو طبيعي

ادمن | جمس اسود

مايك | حنجره

سناكات | ضمادات

مخالف | مسجون**


** باخذ درع | بلبس درع

دسكورد | برنامج الدوله

- لغة السيرفر

تبي تاخذ ايدي شخص | رقم جوالك او واتسك

لفت | سافر

اليد او ازرارها | عضلات ، عضله

دمجته او اطلقت عليه | اصبته ، مصاب

بوت | مدني

لاق | صداع

باند | سفروه المالديف

شات | غرفة

بروح وبجي | باخذ غفوه

بث | سناب او فلوق**
@everyone`;
                break;
            case 'option10':
                response = `**__ — الامـنـاطـق الامـانـه 


— مـركـز الـشـرطـه <a:GOLDEN12:1243477850095489027> 

— الـحـديـقـه الـعـامـه <a:GOLDEN12:1243477850095489027> 

— الـمـسـتـشـفـى <a:GOLDEN12:1243477850095489027> 

 @everyone __**`;
                break;
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`${interaction.guild.name}`)
            .setDescription(response);

        await interaction.deferUpdate();
        await interaction.followUp({ embeds: [embed], ephemeral: true });
    }
}); 


  client.login("MTIwMjI2NjgwMzYxMTM2OTUxMg.GIbbCz.-XpUcENVdB6Odm0A96xaq3HGczwqYjwKbwUUJM")